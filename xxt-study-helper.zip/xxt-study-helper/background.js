/* 后台：右键菜单、快捷键、下载
 *
 * 2024-?? 关键改动：原来只用 tabs.sendMessage 通知页面里的内容脚本，
 * 但内容脚本只在页面加载时注入，用户装好/刷新扩展后打开着的旧标签页里
 * 根本没有它 —— 于是点图标毫无反应、也永远抓不到题目。
 * 现在改成：先探测，缺了就用 chrome.scripting 现场注入，再发消息。
 */

const FILES = [
  'src/common.js',
  'src/extract.js',
  'src/docxgen.js',
  'build/docx.bundle.js',
  'src/ui.js'
];

function send(tabId, msg) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.sendMessage(tabId, msg, (resp) => {
        const err = chrome.runtime.lastError;
        resolve({ ok: !err, error: err ? err.message : '', resp });
      });
    } catch (e) {
      resolve({ ok: false, error: String(e && e.message || e) });
    }
  });
}

// 页面上还有没有活着的脚本
async function probe(tabId) {
  try {
    const [res] = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => !!(window.xxtHelper && typeof window.xxtHelper.doCapture === 'function')
    });
    return !!(res && res.result);
  } catch (e) {
    return false;
  }
}

async function ensureInjected(tabId) {
  if (await probe(tabId)) return true;
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: FILES });
    return true;
  } catch (e) {
    try {
      chrome.action.setBadgeText({ text: '!', tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#dc2626', tabId });
    } catch (_) { /* ignore */ }
    return false;
  }
}

// 统一入口：确保有脚本 → 发消息；发不通就注入后重发一次
async function deliver(tabId, msg) {
  if (!tabId && tabId !== 0) return false;
  let r = await send(tabId, msg);
  if (r.ok) return true;
  const injected = await ensureInjected(tabId);
  if (!injected) return false;
  r = await send(tabId, msg);
  return r.ok;
}

function badge(tabId, text, color) {
  try {
    chrome.action.setBadgeText({ text: text || '', tabId });
    if (color) chrome.action.setBadgeBackgroundColor({ color, tabId });
  } catch (e) { /* ignore */ }
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'xxt-capture', title: '抓取本页学习通题目', contexts: ['page', 'frame', 'selection'] });
    chrome.contextMenus.create({ id: 'xxt-bank', title: '打开已收集题库并导出', contexts: ['page', 'frame'] });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || tab.id == null) return;
  const type = info.menuItemId === 'xxt-bank' ? 'xxt-open-bank' : 'xxt-capture';
  const ok = await deliver(tab.id, { type });
  badge(tab.id, ok ? '' : '!', ok ? null : '#dc2626');
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || tab.id == null) return;
  // 拦一下明显不相关的页面，免得每个站都注入
  const url = tab.url || '';
  if (!/chaoxing\.com|edu\.cn|\.cx\//.test(url)) {
    badge(tab.id, '?', '#6b7280');
    setTimeout(() => badge(tab.id, ''), 2000);
    return;
  }
  const ok = await deliver(tab.id, { type: 'xxt-capture' });
  badge(tab.id, ok ? '' : '!', ok ? null : '#dc2626');
});

chrome.commands.onCommand.addListener(async (command, tab) => {
  if (command !== 'capture-page' || !tab || tab.id == null) return;
  await deliver(tab.id, { type: 'xxt-capture' });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'xxt-download') {
    const url = msg.dataUrl || msg.url;
    if (!url) {
      sendResponse({ ok: false, error: '没有可下载的地址' });
      return false;
    }
    chrome.downloads.download({ url, filename: msg.filename, saveAs: false }, (id) => {
      const err = chrome.runtime.lastError;
      sendResponse({ ok: !err && id != null, error: err ? err.message : '' });
    });
    return true;
  }
  return false;
});
