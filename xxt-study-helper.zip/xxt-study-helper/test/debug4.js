const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const root = __dirname + '\\..';
const target = process.argv[2] || path.join(root, 'test', 'fixture-plain.html');

const html = fs.readFileSync(path.resolve(root, target), 'utf8');
const dom = new JSDOM(html, { runScripts: 'outside-only', url: 'https://mooc1.chaoxing.com/exam/test' });
const w = dom.window;

Object.defineProperty(w.HTMLElement.prototype, 'innerText', {
  get() {
    return this.textContent;
  },
  set(v) {
    this.textContent = v;
  },
  configurable: true
});
const origRect = w.Element.prototype.getBoundingClientRect;
w.Element.prototype.getBoundingClientRect = function () {
  const r = origRect.call(this);
  return { x: 0, y: 0, top: 0, left: 0, right: 400, bottom: 20, width: 400, height: 20, toJSON() {} };
};
w.chrome = {
  runtime: { sendMessage() {}, getURL: (p) => p, onMessage: { addListener() {} } },
  storage: {
    local: {
      _d: {},
      get(k, cb) { cb && cb({}); return Promise.resolve({}); },
      set(o, cb) { cb && cb(); return Promise.resolve(); }
    }
  }
};

for (const f of ['src/common.js', 'src/extract.js']) {
  w.eval(fs.readFileSync(path.join(root, f), 'utf8'));
}

const NS = w.xxtHelper;
console.log('looksLikeExamPage:', NS.looksLikeExamPage());
const qs = NS.extractFrom(w.document.body);
console.log('抽取到', qs.length, '题');
qs.forEach((q, i) => {
  console.log('---');
  console.log(`#${i + 1} [${q.type}] rawId=${q.rawId}`);
  console.log('题干:', q.stem);
  q.options.forEach((o) => console.log(`   ${o.key}. ${o.text}`));
  console.log('我的答案:', q.myAnswer, '| 正确答案:', q.answer, '| 判定:', NS.judge(q.myAnswer, q.answer, q.type));
  console.log('解析:', q.analysis || '(空)');
});
