/* 无头测试：jsdom 加载 fixture.html，跑抽取 + 生成 docx，打印结果 */
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const root = path.resolve(__dirname, '..');
const fixture = process.argv[2] || path.join(root, 'test', 'fixture.html');
const outDocx = path.join(root, 'build', '_fixture.docx');

const vc = new VirtualConsole();
vc.on('error', (...a) => console.error('[page error]', ...a));
vc.on('warn', () => {});

const html = fs.readFileSync(fixture, 'utf8');
const dom = new JSDOM(html, {
  url: 'https://mooc1.chaoxing.com/exam-ans/mooc2/exam/examdetail?examId=1',
  runScripts: 'outside-only',
  pretendToBeVisual: true,
  virtualConsole: vc
});

const { window } = dom;
window.chrome = window.chrome || {};
window.chrome.storage = { local: { get: () => Promise.resolve({}), set: () => Promise.resolve() } };
window.chrome.runtime = { onMessage: { addListener() {} } };
window.HTMLElement.prototype.scrollIntoView = function () {};
// jsdom 无 innerText，用 textContent；无布局，给固定 rect
Object.defineProperty(window.HTMLElement.prototype, 'innerText', {
  configurable: true,
  get() { return this.textContent; },
  set(v) { this.textContent = v; }
});
window.Element.prototype.getBoundingClientRect = function () {
  const st = window.getComputedStyle(this);
  const hidden = st.display === 'none' || st.visibility === 'hidden';
  const w = hidden ? 0 : 10;
  return { x: 0, y: 0, top: 0, left: 0, right: w, bottom: 10, width: w, height: hidden ? 0 : 10 };
};

function inject(file) {
  const code = fs.readFileSync(path.join(root, file), 'utf8');
  window.eval(code);
}

(async () => {
  try {
    for (const f of ['src/common.js', 'src/extract.js', 'build/docx.bundle.js', 'src/docxgen.js']) inject(f);
    const NS = window.xxtHelper;
    if (!NS) throw new Error('xxtHelper 没加载成功');
    console.log('module keys:', Object.keys(NS).join(','));
    console.log('docx 库:', window.docx ? Object.keys(window.docx).length + ' 个导出' : '无');

    const t0 = Date.now();
    const qs = NS.extractFrom(window.document.body);
    console.log(`\n=== 抽取到 ${qs.length} 题（${Date.now() - t0}ms） ===`);
    for (const q of qs) {
      console.log('---');
      console.log(`#${q.index} [${q.type}] rawId=${q.rawId || '-'}`);
      console.log('题干:', q.stem);
      (q.options || []).forEach((o) => console.log(`   ${o.key}. ${o.text}`));
      console.log('我的答案:', q.myAnswer || '(空)', '| 正确答案:', q.answer || '(空)', '| 判定:', NS.judge(q.myAnswer, q.answer, q.type) || '-');
      console.log('解析:', q.analysis || '(空)');
    }

    const blob = await NS.buildDocx(qs, {
      title: '自测试卷 复习题',
      subtitle: '自测导出',
      withAnswer: true,
      withAnalysis: true
    });
    const buf = Buffer.from(await blob.arrayBuffer());
    fs.writeFileSync(outDocx, buf);
    console.log(`\n=== docx 已生成: ${outDocx} (${buf.length} bytes) ===`);
    process.exit(0);
  } catch (e) {
    console.error('TEST FAILED:', e && e.stack || e);
    process.exit(1);
  }
})();
