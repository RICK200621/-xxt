/* 页面 UI：抓取按钮 / 预览面板 / 下载 */
(function () {
  const NS = (globalThis.xxtHelper = globalThis.xxtHelper || {});
  if (NS.uiReady) return;
  // 只在最外层框架显示 UI（iframe 只负责抽取，由父页聚合）
  if (window.top !== window) return;
  const host = location.hostname;
  if (!/(chaoxing|edu\.cn|\.cx$)/.test(host)) return;

  NS.uiReady = true;

  const judge = (a, b, t) => (NS.judge ? NS.judge(a, b, t) : '');
  const squash = (t) => String(t || '').replace(/\n{2,}/g, '\n').trim();
  const esc = (s) =>
    String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  let panel = null;
  let curMode = 'page';       // page = 本页抓取 / bank = 已收集题库
  let batchItems = [];        // 连续抓取模式下的题目
  let captureHook = null;

  /* ---------------- 样式 ---------------- */
  const CSS = `
  .xxh-fab{position:fixed;right:18px;bottom:96px;z-index:2147483646;display:flex;flex-direction:column;gap:8px;font-family:"Microsoft YaHei",sans-serif}
  .xxh-fab button{cursor:pointer;border:none;border-radius:20px;padding:10px 16px;font-size:13px;color:#fff;
    background:linear-gradient(135deg,#3b82f6,#2563eb);box-shadow:0 4px 14px rgba(37,99,235,.4);transition:.15s}
  .xxh-fab button:hover{transform:translateY(-1px);filter:brightness(1.08)}
  .xxh-fab button.xxh-sec{background:linear-gradient(135deg,#64748b,#475569);box-shadow:0 4px 14px rgba(71,85,105,.35)}
  .xxh-mask{position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:"Microsoft YaHei",sans-serif}
  .xxh-panel{width:min(1040px,95vw);height:min(780px,93vh);background:#fff;border-radius:12px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.35)}
  .xxh-head{display:flex;align-items:center;gap:8px;padding:12px 16px;background:#f8fafc;border-bottom:1px solid #e2e8f0;flex-wrap:wrap}
  .xxh-head h3{margin:0;font-size:15px;color:#0f172a;font-weight:700}
  .xxh-tag{font-size:12px;color:#475569;background:#e2e8f0;border-radius:10px;padding:2px 8px;white-space:nowrap}
  .xxh-tag.xxh-warn{background:#fef3c7;color:#92400e}
  .xxh-grow{flex:1}
  .xxh-head button{cursor:pointer;border:1px solid #cbd5e1;background:#fff;color:#334155;border-radius:6px;padding:6px 12px;font-size:13px}
  .xxh-head button.xxh-primary{background:#2563eb;border-color:#2563eb;color:#fff;font-weight:600}
  .xxh-head button:disabled{opacity:.5;cursor:not-allowed}
  .xxh-head button:hover:not(:disabled){filter:brightness(.96)}
  .xxh-opts{display:flex;gap:14px;align-items:center;padding:8px 16px;border-bottom:1px solid #eef2f7;font-size:13px;color:#475569;flex-wrap:wrap}
  .xxh-opts label{display:flex;gap:4px;align-items:center;cursor:pointer;user-select:none}
  .xxh-opts .xxh-hint{color:#94a3b8;font-size:12px}
  .xxh-mode{display:flex;gap:6px;padding:8px 16px;border-bottom:1px solid #eef2f7;background:#fbfdff}
  .xxh-mode button{cursor:pointer;border:1px solid #dbe3ee;background:#fff;color:#475569;border-radius:14px;padding:4px 12px;font-size:12px}
  .xxh-mode button.on{background:#2563eb;border-color:#2563eb;color:#fff}
  .xxh-body{flex:1;overflow:auto;padding:12px 16px;background:#fafbfc}
  .xxh-q{border:1px solid #e5e7eb;border-radius:8px;padding:10px 12px;margin-bottom:10px;background:#fff}
  .xxh-q.xxh-wrong{border-left:4px solid #dc2626}
  .xxh-q.xxh-right{border-left:4px solid #16a34a}
  .xxh-stem{font-size:14px;color:#111827;font-weight:600;margin-bottom:6px;line-height:1.6;white-space:pre-wrap;word-break:break-word}
  .xxh-opt{font-size:13px;color:#374151;margin:2px 0 2px 14px;line-height:1.5;white-space:pre-wrap}
  .xxh-opt.xxh-isans{color:#dc2626;font-weight:700}
  .xxh-opt.xxh-ismine{color:#6b7280;font-style:italic}
  .xxh-row{font-size:13px;margin-top:4px;line-height:1.6;color:#1f2937;white-space:pre-wrap}
  .xxh-row b{color:#475569;font-weight:600}
  .xxh-ana{font-size:13px;color:#4b5563;background:#f3f4f6;border-radius:6px;padding:6px 8px;margin-top:6px;line-height:1.65;white-space:pre-wrap;word-break:break-word}
  .xxh-badge{display:inline-block;font-size:11px;padding:1px 6px;border-radius:8px;margin-right:6px;background:#e0e7ff;color:#3730a3}
  .xxh-badge.xxh-ok{background:#dcfce7;color:#166534}
  .xxh-badge.xxh-bad{background:#fee2e2;color:#991b1b}
  .xxh-empty{color:#94a3b8;text-align:center;padding:60px 0;font-size:14px;line-height:1.8}
  .xxh-toast{position:fixed;right:20px;bottom:20px;z-index:2147483647;max-width:380px;background:#0f172a;color:#fff;padding:10px 16px;border-radius:8px;font-size:13px;line-height:1.6;font-family:"Microsoft YaHei",sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.3)}
  .xxh-edit{border:1px dashed #cbd5e1;border-radius:6px;padding:6px 8px;margin-top:6px;font-size:12px;color:#94a3b8;background:#f8fafc}
  .xxh-edit input,.xxh-edit textarea{width:100%;border:1px solid #cbd5e1;border-radius:4px;padding:4px 6px;font-size:12px;margin-top:4px;box-sizing:border-box;font-family:inherit;resize:vertical}
  `;

  function injectCss() {
    if (document.getElementById('xxh-style')) return;
    const s = document.createElement('style');
    s.id = 'xxh-style';
    s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }

  function toast(msg, ms) {
    injectCss();
    let t = document.querySelector('.xxh-toast');
    if (!t) {
      t = document.createElement('div');
      t.className = 'xxh-toast';
      document.documentElement.appendChild(t);
    }
    t.textContent = msg;
    clearTimeout(t._h);
    t._h = setTimeout(() => t.remove(), ms || 2800);
  }

  /* ---------------- 抓取：跨 frame 聚合 ---------------- */

  function collectFrames() {
    const frames = [{ win: window, doc: document, depth: 0 }];
    let i = 0;
    while (i < frames.length) {
      const f = frames[i++];
      let iframes = [];
      try { iframes = [...f.doc.querySelectorAll('iframe,frame')]; } catch (e) { iframes = []; }
      for (const ifr of iframes) {
        let w = null, d = null;
        try {
          w = ifr.contentWindow;
          d = w && w.document;
          if (d && d.readyState === 'uninitialized') d = null;
        } catch (e) { d = null; }
        if (w && d) frames.push({ win: w, doc: d, depth: f.depth + 1 });
      }
    }
    return frames;
  }

  function extractAll() {
    const groups = [];
    for (const f of collectFrames()) {
      try {
        // 注意：frame 对象的键是 win / doc，别写成 f.w（之前就是这里的笔误，
        // 导致取到 undefined 抛异常被下面的 catch 吞掉，于是永远「抓不到题目」）
        const helper = f.win && f.win.xxtHelper;
        if (!helper || !helper.extractFrom) continue;
        const qs = helper.extractFrom(f.doc.body);
        if (qs && qs.length) groups.push(qs);
      } catch (e) { /* 跨域，跳过 */ }
    }
    groups.sort((a, b) => b.length - a.length);
    const out = [];
    const seenIds = new Set();
    for (const g of groups) {
      for (const q of g) {
        // 有 rawId 就只按 rawId 判重：学习通里同题干但选项不同的题很常见，
        // 之前按题干相似度去重会把它误删（200 题变成 199 题）
        if (q.rawId) {
          if (seenIds.has(q.rawId)) continue;
          seenIds.add(q.rawId);
          out.push(q);
          continue;
        }
        const dup = out.some((x) => {
          if (x.rawId) return false;
          return x.stem && q.stem && (x.stem === q.stem || NS.similar(x.stem, q.stem) > 0.9);
        });
        if (!dup) out.push(q);
      }
    }
    return out;
  }

  async function captureCurrent() {
    let qs = [];
    try { qs = extractAll(); } catch (e) { console.error(e); }
    return qs;
  }

  async function doCapture(silent) {
    injectCss();
    if (!silent) toast('正在抓取本页题目…');
    const qs = await captureCurrent();
    if (!qs.length) {
      console.warn('[学习通抓题] 没抓到题目', NS.diagnose ? NS.diagnose() : '');
      toast('没抓到题目（v' + (NS.VERSION || '?') + '）。' + diagnoseText(), 12000);
      return [];
    }
    if (captureHook) captureHook(qs);
    else if (!silent) {
      // 没有面板时自动存题库并打开预览
      const bank = await NS.loadBank();
      const r = NS.mergeQuestions(bank, qs, { title: document.title, url: location.href });
      await NS.saveBank(r.bank);
      toast(`本页抓到 ${qs.length} 题，已加入题库（新增 ${r.added}，补全 ${r.updated}）`);
      showPanel(qs, 'page', [qs]);
    }
    return qs;
  }

  /** 抓不到时给一句能看出断在哪的话 */
  function diagnoseText() {
    let d = null;
    try { d = NS.diagnose ? NS.diagnose() : null; } catch (e) { d = null; }
    if (!d) return ' 先按 Ctrl+R 刷新页面再试；若扩展刚更新过，去 edge://extensions 点一下刷新。';
    let s = '';
    if (d.links && d.links.length) {
      const top = d.links.slice(0, 3).map((x) => x[0] + '×' + x[1]).join('、');
      s += ' 认出了 ' + top + '，但解析出 0 题。';
    } else if (d.bodyLen < 200) {
      s += ' 页面正文只有 ' + d.bodyLen + ' 字，可能没加载完或没登录。';
    } else {
      s += ' 页面正文 ' + d.bodyLen + ' 字，但没认出任何题目容器。';
    }
    s += ' 若是扩展刚更新过：去 edge://extensions 点扩展的刷新，再 Ctrl+R 重开本页。';
    return s;
  }

  /* ---------------- 面板 ---------------- */

  function showPanel(list, mode, batch) {
    injectCss();
    curMode = mode || 'page';
    batchItems = batch !== undefined ? batch : list ? [list] : [];
    if (panel) panel.remove();

    const mask = document.createElement('div');
    mask.className = 'xxh-mask';
    const s = calcStats(list);
    mask.innerHTML = `
      <div class="xxh-panel">
        <div class="xxh-head">
          <h3>${curMode === 'bank' ? '已收集题库' : '本页抓取预览'}</h3>
          <span class="xxh-tag" id="xxh-stat"></span>
          <span class="xxh-tag" id="xxh-ver" style="background:#f1f5f9;color:#64748b">v${esc(NS.VERSION || '?')}</span>
          <span class="xxh-grow"></span>
          <button class="xxh-primary" data-act="download">下载 Word</button>
          <button data-act="reload">重新抓取本页</button>
          <button data-act="close">关闭</button>
        </div>
        <div class="xxh-mode">
          <button data-mode="page">本页抓取</button>
          <button data-mode="bank">已收集题库</button>
          <button data-act="batch" style="margin-left:8px">连续抓取：开</button>
          <span class="xxh-hint" style="color:#94a3b8;font-size:12px;margin-left:auto">连续抓取：开着面板翻页/滚动，抓到就自动并进来</span>
        </div>
        <div class="xxh-opts">
          <label><input type="checkbox" id="xxh-ans" checked> 含答案解析</label>
          <label><input type="checkbox" id="xxh-onlywrong"> 只导出错题</label>
          <span class="xxh-hint">预览里缺失的解析可以直接补，会写进 Word</span>
        </div>
        <div class="xxh-body"></div>
      </div>`;
    panel = mask;

    mask.addEventListener('click', (e) => { if (e.target === mask) closePanel(); });
    mask.querySelector('[data-act="close"]').onclick = closePanel;
    mask.querySelector('[data-act="download"]').onclick = () => download();
    mask.querySelector('[data-act="reload"]').onclick = async () => {
      const qs = await doCapture(true);
      if (qs.length) addToBatch(qs);
    };
    mask.querySelector('[data-act="batch"]').onclick = (e) => {
      if (captureHook) stopBatch();
      else startBatch();
    };
    mask.querySelectorAll('[data-mode]').forEach((b) => {
      b.onclick = () => switchMode(b.getAttribute('data-mode'));
    });
    mask.querySelector('#xxh-onlywrong').onchange = () => renderBody();
    mask.querySelector('#xxh-ans').onchange = () => renderBody();

    updateStat();
    renderBody();
    document.documentElement.appendChild(mask);
  }

  function calcStats(list) {
    let wrong = 0, noAna = 0, noAns = 0;
    for (const q of list) {
      if (judge(q.myAnswer, q.answer, q.type) === 'wrong') wrong++;
      if (!q.analysis) noAna++;
      if (!q.answer) noAns++;
    }
    return { total: list.length, wrong, noAna, noAns };
  }

  function currentList() {
    if (curMode === 'bank') return window.__xxhBankList || [];
    const flat = [];
    for (const g of batchItems) for (const q of g) if (!flat.includes(q)) flat.push(q);
    return flat;
  }

  function updateStat() {
    if (!panel) return;
    const st = calcStats(currentList());
    const el = panel.querySelector('#xxh-stat');
    let s = `${st.total} 题`;
    if (st.wrong) s += ` · 错 ${st.wrong}`;
    if (st.noAna) s += ` · 无解析 ${st.noAna}`;
    if (st.noAns) s += ` · 无答案 ${st.noAns}`;
    el.textContent = s;
    el.className = 'xxh-tag' + (st.noAna || st.noAns ? ' xxh-warn' : '');
    const bb = panel.querySelector('[data-act="batch"]');
    if (bb) bb.textContent = '连续抓取：' + (captureHook ? '开' : '关');
    panel.querySelectorAll('[data-mode]').forEach((b) => {
      b.classList.toggle('on', b.getAttribute('data-mode') === curMode);
    });
  }

  function renderBody() {
    if (!panel) return;
    const body = panel.querySelector('.xxh-body');
    body.innerHTML = '';
    let list = currentList();
    if (curMode === 'bank') {
      const box = document.createElement('div');
      box.innerHTML = `
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;align-items:center">
          <button class="xxh-primary2" data-bank="export" style="cursor:pointer;border:1px solid #2563eb;background:#2563eb;color:#fff;border-radius:6px;padding:6px 12px">导出全部题库</button>
          <button data-bank="clear" style="cursor:pointer;border:1px solid #fecaca;background:#fff;color:#b91c1c;border-radius:6px;padding:6px 12px">清空题库</button>
          <span style="color:#94a3b8;font-size:12px">题库来自你点过"抓取本页题目"的所有页面（自动去重合并）</span>
        </div>`;
      box.querySelector('[data-bank="export"]').onclick = () => download('bank');
      box.querySelector('[data-bank="clear"]').onclick = async () => {
        if (!confirm('确定清空已收集的全部题目？')) return;
        await NS.saveBank({ questions: [], batches: [], updatedAt: Date.now() });
        window.__xxhBankList = [];
        updateStat();
        renderBody();
        toast('题库已清空');
      };
      body.appendChild(box);
    }
    if (panel.querySelector('#xxh-onlywrong') && panel.querySelector('#xxh-onlywrong').checked) {
      list = list.filter((q) => judge(q.myAnswer, q.answer, q.type) === 'wrong');
    }
    if (!list.length) {
      const empty = document.createElement('div');
      empty.className = 'xxh-empty';
      empty.innerHTML =
        curMode === 'bank'
          ? '题库还是空的。<br>去已完成考试的回顾页，点右下角"抓取本页题目"。'
          : '这一组没有题目。';
      body.appendChild(empty);
      updateStat();
      return;
    }
    list.forEach((q, i) => body.appendChild(qNode(q, i + 1)));
    updateStat();
  }

  function qNode(q, idx) {
    const v = judge(q.myAnswer, q.answer, q.type);
    const el = document.createElement('div');
    el.className = 'xxh-q ' + (v === 'wrong' ? 'xxh-wrong' : v === 'correct' ? 'xxh-right' : '');
    const head = document.createElement('div');
    head.innerHTML = `<span class="xxh-badge">${esc(q.type || '题目')}</span>`;
    const stem = document.createElement('span');
    stem.className = 'xxh-stem';
    stem.textContent = `${idx}. ` + squash(q.stem);
    head.appendChild(stem);
    el.appendChild(head);

    (q.options || []).forEach((o) => {
      const d = document.createElement('div');
      const isAns = q.answer && q.answer.includes(o.key);
      const isMine = q.myAnswer && q.myAnswer.includes(o.key);
      d.className = 'xxh-opt' + (isAns ? ' xxh-isans' : '') + (isMine && !isAns ? ' xxh-ismine' : '');
      d.textContent = `${o.key}. ${o.text}${isAns ? '  ✔' : ''}${isMine && !isAns ? '  ✘' : ''}`;
      el.appendChild(d);
    });

    if (q.myAnswer) {
      const r = document.createElement('div');
      r.className = 'xxh-row';
      r.innerHTML = '<b>我的答案：</b>';
      r.appendChild(document.createTextNode(q.myAnswer));
      if (v) {
        const s = document.createElement('span');
        s.className = 'xxh-badge ' + (v === 'correct' ? 'xxh-ok' : 'xxh-bad');
        s.textContent = v === 'correct' ? '答对' : '答错';
        s.style.marginLeft = '8px';
        r.appendChild(s);
      }
      el.appendChild(r);
    }
    if (q.answer) {
      const r = document.createElement('div');
      r.className = 'xxh-row';
      r.innerHTML = '<b>正确答案：</b>';
      r.appendChild(document.createTextNode(q.answer));
      el.appendChild(r);
    }
    if (q.analysis) {
      const a = document.createElement('div');
      a.className = 'xxh-ana';
      a.textContent = squash(q.analysis);
      a.contentEditable = 'true';
      a.title = '解析可以直接改，保存时以修改后的为准';
      a.oninput = () => { q._edited = true; };
      el.appendChild(a);
    } else {
      const wrap = document.createElement('div');
      wrap.className = 'xxh-edit';
      wrap.textContent = '没抓到解析（页面里本来就没有的话，可以直接补）';
      const ta = document.createElement('textarea');
      ta.rows = 2;
      ta.placeholder = '手填解析，会写进 Word';
      ta.value = q.analysis || '';
      ta.oninput = () => { q.analysis = ta.value.trim(); q._edited = true; updateStat(); };
      wrap.appendChild(ta);
      el.appendChild(wrap);
    }
    return el;
  }

  async function switchMode(mode) {
    curMode = mode;
    if (mode === 'bank') {
      const bank = await NS.loadBank();
      window.__xxhBankList = NS.sortQuestions(bank.questions || []);
      if (!window.__xxhBankList.length) toast('题库还是空的，先去考试回顾页抓一次');
    }
    renderBody();
  }

  function addToBatch(qs) {
    if (!panel) return;
    let added = 0;
    const flat = currentList();
    const pack = [];
    for (const q of qs) {
      const dup = flat.some((x) => {
        if (x.rawId && q.rawId && x.rawId === q.rawId) return true;
        return x.stem && q.stem && (x.stem === q.stem || NS.similar(x.stem, q.stem) > 0.9);
      });
      if (!dup) { pack.push(q); flat.push(q); added++; }
    }
    if (!added) return toast('这页的题都已经在里面了');
    batchItems.push(pack);
    renderBody();
    toast(`并入 ${added} 题，累计 ${currentList().length} 题`);
  }

  function startBatch() {
    if (captureHook) { stopBatch(); return; }
    captureHook = (qs) => {
      addToBatch(qs);
      persistBatch();
    };
    updateStat();
    toast('连续抓取已开：翻到下一页/下一套后自动并入');
  }

  function stopBatch() {
    captureHook = null;
    if (panel) updateStat();
    toast('连续抓取已关');
  }

  async function persistBatch() {
    const flat = currentList();
    if (!flat.length) return;
    const bank = await NS.loadBank();
    const r = NS.mergeQuestions(bank, flat, { title: document.title, url: location.href });
    await NS.saveBank(r.bank);
  }

  function closePanel() {
    captureHook = null;
    if (panel) { panel.remove(); panel = null; }
    // 关面板时把抓到的题存进题库
    persistBatch();
  }

  /* ---------------- 下载 ---------------- */

  // 导出文件名用的标题：学习通页面标题常常只是「查看详情」，真正的卷名在 .mark_title 里
  function guessTitle() {
    const mt = document.querySelector('.mark_title, .mark_title_name, .examName, .courseName');
    if (mt) {
      const v = NS.oneLine(mt.textContent || '');
      if (v && v.length <= 60) return v;
    }
    const t = (document.title || '').replace(/\s*[-|_—]\s*.*$/, '').trim();
    if (t && !/^(查看详情|考试详情|作业详情|试卷详情|学生详情|考试列表)$/.test(t)) return t;
    return '学习通试卷';
  }

  function download(forcedMode) {
    const mode = forcedMode || curMode;
    let list = (mode === 'bank' ? window.__xxhBankList || [] : currentList()).slice();
    const onlyWrong = !!(panel && panel.querySelector('#xxh-onlywrong').checked);
    const withAnswer = !panel || panel.querySelector('#xxh-ans').checked;
    if (onlyWrong) list = list.filter((q) => judge(q.myAnswer, q.answer, q.type) === 'wrong');
    if (!list.length) return toast(onlyWrong ? '没有错题可导出' : '还没有题目可导出');
    const title = guessTitle();
    const opt = {
      title: title + ' 复习题',
      subtitle: `导出时间 ${new Date().toLocaleString('zh-CN')}｜共 ${list.length} 题`,
      withAnswer,
      withAnalysis: true,
      onlyWrong
    };
    toast('正在生成 Word…');
    NS.buildDocx(list, opt)
      .then((blob) => {
        const name = NS.safeName(opt.title) + '-' + NS.stamp() + '.docx';

        // 主路径：就在页面里用 blob: URL + <a download> 直接触发下载，
        // 完全不经过 background service worker（之前把 blob: 交给 chrome.downloads
        // 会跨源失败、转 data: URL 也容易被拦）。这个 blob URL 属于页面自己的源，
        // a[download] 是浏览器原生保存，最稳。
        const saveByAnchor = () => {
          const url = URL.createObjectURL(blob);
          let a = null;
          try {
            a = document.createElement('a');
            a.href = url;
            a.download = name;
            a.rel = 'noopener';
            a.style.display = 'none';
            (document.body || document.documentElement).appendChild(a);
            a.click();
            return true;
          } catch (e) {
            console.warn('[学习通抓题] a[download] 失败', e);
            return false;
          } finally {
            // 给浏览器留足时间把 blob 读走，再清理
            setTimeout(() => {
              try { if (a && a.parentNode) a.parentNode.removeChild(a); } catch (e2) {}
              try { URL.revokeObjectURL(url); } catch (e2) {}
            }, 120000);
          }
        };

        // 备用路径：万一 a[download] 被拦，再走后台 downloads + data: URL
        const saveByBackground = () => {
          const buf2b64 = async () => {
            const buf = new Uint8Array(await blob.arrayBuffer());
            let bin = '';
            const CH = 0x8000;
            for (let i = 0; i < buf.length; i += CH) {
              bin += String.fromCharCode.apply(null, buf.subarray(i, i + CH));
            }
            return (
              'data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,' +
              btoa(bin)
            );
          };
          buf2b64()
            .then((dataUrl) =>
              chrome.runtime.sendMessage({ type: 'xxt-download', dataUrl, filename: name }, (resp) => {
                const err = chrome.runtime.lastError;
                if (err || !resp || !resp.ok) {
                  toast('两种下载方式都失败了：' + (err ? err.message : (resp && resp.error) || '后台无响应'), 9000);
                } else {
                  toast('已下载：' + name + '（在「下载」文件夹）', 6000);
                }
              })
            )
            .catch((e) => toast('下载失败：' + (e && e.message ? e.message : e), 9000));
        };

        if (saveByAnchor()) {
          toast('已保存：' + name + '\n文件在「下载」文件夹', 7000);
        } else {
          saveByBackground();
        }
        if (mode !== 'bank') persistBatch();
      })
      .catch((e) => {
        console.error(e);
        toast('生成失败：' + e.message, 5000);
      });
  }

  /* ---------------- 入口按钮 ---------------- */

  function mountFab() {
    if (document.querySelector('.xxh-fab')) return;
    injectCss();
    const fab = document.createElement('div');
    fab.className = 'xxh-fab';
    fab.innerHTML = `
      <button data-act="capture" title="Alt+Shift+S 也可以">抓取本页题目</button>
      <button class="xxh-sec" data-act="bank" title="查看/导出已收集的题库">题库导出</button>`;
    fab.querySelector('[data-act="capture"]').onclick = () => doCapture(false);
    fab.querySelector('[data-act="bank"]').onclick = async () => {
      const bank = await NS.loadBank();
      window.__xxhBankList = NS.sortQuestions(bank.questions || []);
      showPanel([], 'bank', []);
    };
    document.documentElement.appendChild(fab);
  }

  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (!msg) return;
      if (msg.type === 'xxt-capture') doCapture(false);
      else if (msg.type === 'xxt-open-bank') {
        mountFab();
        const b = document.querySelector('.xxh-fab [data-act="bank"]');
        if (b) b.click();
      }
    });
  } catch (e) { /* 上下文失效时忽略 */ }

  window.addEventListener('keydown', (e) => {
    if (e.altKey && e.shiftKey && (e.key === 'S' || e.key === 's')) {
      e.preventDefault();
      mountFab();
      doCapture(false);
    }
    if (e.key === 'Escape' && panel) closePanel();
  });

  // 像试卷的页面自动挂按钮；也认「有一堆 .questionLi」的页面，
  // 因为有些回顾页标题就叫「查看详情」，正文前 3000 字里根本没有关键词
  const boot = () => {
    try {
      const hasBlocks = !!document.querySelector('.questionLi, [data-questionid], .singleQuesId');
      if (hasBlocks || NS.looksLikeExamPage()) mountFab();
    } catch (e) { /* ignore */ }
  };
  if (document.readyState === 'loading') window.addEventListener('load', () => setTimeout(boot, 900), { once: true });
  else setTimeout(boot, 900);

  NS.doCapture = () => doCapture(false);
  NS.mountFab = mountFab;
})();
