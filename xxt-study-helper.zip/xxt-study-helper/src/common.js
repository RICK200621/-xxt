/* 公共工具：命名空间、文本清洗、题库存储 */
(function () {
  const NS = (globalThis.xxtHelper = globalThis.xxtHelper || {});
  if (NS.ready) return;
  NS.ready = true;

  // 版本号：面板/提示里会显示，用来确认页面上跑的是不是最新代码
  NS.VERSION = '1.3.1';

  NS.STORAGE_KEY = 'xxt_helper_bank_v1';
  NS.SETTINGS_KEY = 'xxt_helper_settings_v1';

  /** 文本规整：去零宽、合并空白、去首尾 */
  NS.clean = function (s) {
    if (s == null) return '';
    return String(s)
      .replace(/[\u200b-\u200f\u202a-\u202e\ufeff]/g, '')
      .replace(/[\u00a0\u3000]/g, ' ')
      .replace(/[ \t]+/g, ' ')
      .replace(/\s*\n\s*/g, '\n')
      .trim();
  };

  /** 单行规整 */
  NS.oneLine = function (s) {
    return NS.clean(s).replace(/\n+/g, ' ');
  };

  /** 去掉题干里已有的题号前缀，返回 {text, num} */
  NS.stripLeadingNumber = function (s) {
    const m = String(s || '').match(/^\s*(?:第\s*(\d+)\s*题\s*[.、:：]?|(\d+)\s*[.、．)）:：]\s*)/);
    if (!m) return { text: String(s || '').trim(), num: null };
    return { text: String(s).slice(m[0].length).trim(), num: Number(m[1] || m[2]) };
  };

  /** 题库题目标识 */
  NS.qid = function (q) {
    const k = (q.rawId || '') + '|' + (q.stem || '').slice(0, 200);
    let h = 5381;
    for (let i = 0; i < k.length; i++) h = ((h << 5) + h + k.charCodeAt(i)) | 0;
    return 'q' + (h >>> 0).toString(36);
  };

  /** 相似度（字符二元组 Jaccard），用于跨页面去重 */
  NS.similar = function (a, b) {
    a = (a || '').replace(/\s+/g, '');
    b = (b || '').replace(/\s+/g, '');
    if (!a || !b) return 0;
    if (a === b) return 1;
    const grams = (s) => {
      const set = new Set();
      for (let i = 0; i < s.length - 1; i++) set.add(s.slice(i, i + 2));
      return set;
    };
    const A = grams(a), B = grams(b);
    if (!A.size || !B.size) return 0;
    let inter = 0;
    for (const g of A) if (B.has(g)) inter++;
    return inter / (A.size + B.size - inter);
  };

  /** 读取题库 */
  NS.loadBank = async function () {
    try {
      const r = await chrome.storage.local.get(NS.STORAGE_KEY);
      const bank = r[NS.STORAGE_KEY];
      if (bank && Array.isArray(bank.questions)) return bank;
    } catch (e) {
      console.warn('[学习通导出] 读取题库失败', e);
    }
    return { questions: [], batches: [], updatedAt: 0 };
  };

  /** 保存题库 */
  NS.saveBank = async function (bank) {
    bank.updatedAt = Date.now();
    await chrome.storage.local.set({ [NS.STORAGE_KEY]: bank });
    return bank;
  };

  /**
   * 合并题目（按 原始ID / 题干相似度 去重，新数据补充旧数据）
   * @returns {{bank, added:number, updated:number}}
   */
  NS.mergeQuestions = function (bank, incoming, meta) {
    let added = 0, updated = 0;
    const list = bank.questions;
    const now = Date.now();
    for (const q of incoming) {
      q.id = NS.qid(q);
      let hit = null;
      if (q.rawId) hit = list.find((x) => x.rawId && String(x.rawId) === String(q.rawId));
      if (!hit) {
        hit = list.find((x) => {
          if (x.rawId && q.rawId) return false;
          if (NS.similar(x.stem, q.stem) >= 0.9) return true;
          return false;
        });
      }
      if (hit) {
        const before = JSON.stringify([hit.stem, hit.options, hit.myAnswer, hit.answer, hit.analysis, hit.type]);
        // 只补空字段，不覆盖已有内容
        for (const k of ['stem', 'myAnswer', 'answer', 'analysis', 'type', 'index', 'sourceUrl']) {
          if (!hit[k] && q[k]) hit[k] = q[k];
        }
        if ((!hit.options || !hit.options.length) && q.options && q.options.length) hit.options = q.options;
        hit.updatedAt = now;
        if (JSON.stringify([hit.stem, hit.options, hit.myAnswer, hit.answer, hit.analysis, hit.type]) !== before) updated++;
      } else {
        q.createdAt = now;
        q.updatedAt = now;
        list.push(q);
        added++;
      }
    }
    if (meta) {
      bank.batches = bank.batches || [];
      bank.batches.push({ ...meta, at: now, count: incoming.length, added, updated });
      if (bank.batches.length > 50) bank.batches = bank.batches.slice(-50);
    }
    if (meta && meta.title) bank.title = bank.title || meta.title;
    return { bank, added, updated };
  };

  /** 题目在题库中的顺序修正：按题型+题干长度稳定排序做兜底 */
  NS.sortQuestions = function (list) {
    return list.slice().sort((a, b) => {
      const ta = a.typeRank == null ? 99 : a.typeRank;
      const tb = b.typeRank == null ? 99 : b.typeRank;
      if (ta !== tb) return ta - tb;
      const ia = a.index == null ? 1e9 : a.index;
      const ib = b.index == null ? 1e9 : b.index;
      if (ia !== ib) return ia - ib;
      return (a.createdAt || 0) - (b.createdAt || 0);
    });
  };

  /** 安全秒级文件名时间 */
  NS.stamp = function (d) {
    d = d || new Date();
    const p = (n) => String(n).padStart(2, '0');
    return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}`;
  };

  /** 文件名清洗 */
  NS.safeName = function (s) {
    return (s || '学习通试卷').replace(/[\\/:*?"<>|\r\n]+/g, '_').slice(0, 80);
  };
})();
