/* Word 生成：把题目数组渲染成 .docx（依赖 build/docx.bundle.js 提供的 window.docx） */
(function () {
  const NS = (globalThis.xxtHelper = globalThis.xxtHelper || {});
  if (NS.docxgen) return;
  NS.docxgen = true;

  function D() {
    const d = globalThis.docx || (typeof window !== 'undefined' ? window.docx : null);
    if (!d) throw new Error('docx 库未加载');
    return d;
  }

  const judge = (a, b, t) => (NS.judge ? NS.judge(a, b, t) : '');

  function labelPara(text, color) {
    const { Paragraph, TextRun } = D();
    return new Paragraph({
      spacing: { before: 60, after: 20 },
      children: [new TextRun({ text, color: color || '333333' })]
    });
  }

  function textPara(text, opts) {
    const { Paragraph, TextRun } = D();
    opts = opts || {};
    return new Paragraph({
      spacing: { before: opts.before == null ? 20 : opts.before, after: opts.after == null ? 20 : opts.after },
      indent: opts.indent,
      children: [new TextRun({ text, bold: !!opts.bold, italics: !!opts.italics, color: opts.color, size: opts.size })]
    });
  }

  /** 一题 -> 段落数组 */
  function questionParas(q, idx, withAnswer, withAnalysis) {
    const { Paragraph, TextRun } = D();
    const out = [];
    const verdict = judge(q.myAnswer, q.answer, q.type);
    const verdictTag = verdict === 'correct' ? '【答对】' : verdict === 'wrong' ? '【答错】' : '';
    const stemText = NS.stripLeadingNumber ? NS.stripLeadingNumber(q.stem).text : q.stem;

    // 题干
    out.push(
      new Paragraph({
        spacing: { before: 200, after: 60 },
        children: [
          new TextRun({ text: `${idx}. `, bold: true }),
          new TextRun({
            text: (q.type ? `（${q.type}）` : '') + (verdictTag ? verdictTag : '') + stemText,
            bold: true
          })
        ]
      })
    );

    // 选项
    (q.options || []).forEach((o) => {
      const isAns = q.answer && q.answer.includes(o.key);
      const isMine = q.myAnswer && q.myAnswer.includes(o.key);
      let prefix = '';
      if (isAns && isMine) prefix = '✓';
      else if (isAns) prefix = '✔';
      else if (isMine) prefix = '✘';
      out.push(
        new Paragraph({
          indent: { left: 360 },
          spacing: { before: 10, after: 10 },
          children: [
            new TextRun({
              text: `${o.key}. ${o.text}`,
              bold: !!isAns,
              color: isAns ? 'C00000' : isMine ? '7A7A7A' : undefined
            }),
            ...(prefix ? [new TextRun({ text: `  ${prefix}`, color: isAns ? 'C00000' : '7A7A7A', bold: !!isAns })] : [])
          ]
        })
      );
    });

    // 我的答案
    if (q.myAnswer) {
      out.push(
        new Paragraph({
          spacing: { before: 60, after: 20 },
          children: [
            new TextRun({ text: '我的答案：', bold: true, color: '444444' }),
            new TextRun({ text: q.myAnswer, color: verdict === 'wrong' ? 'C00000' : '1F6E1F' })
          ]
        })
      );
    }

    // 正确答案
    if (withAnswer) {
      if (q.answer) {
        out.push(
          new Paragraph({
            spacing: { before: 20, after: 20 },
            children: [
              new TextRun({ text: '正确答案：', bold: true, color: '444444' }),
              new TextRun({ text: q.answer, bold: true, color: 'C00000' })
            ]
          })
        );
      } else {
        // 页面没下发答案时留空行，方便复习时手写
        out.push(
          new Paragraph({
            spacing: { before: 20, after: 20 },
            children: [
              new TextRun({ text: '正确答案：', bold: true, color: '444444' }),
              new TextRun({ text: '________________', color: 'BBBBBB' })
            ]
          })
        );
      }
    }

    // 解析
    if (withAnalysis) {
      const ana = (q.analysis || '').trim();
      out.push(
        new Paragraph({
          spacing: { before: 20, after: 20 },
          children: [new TextRun({ text: '解析：', bold: true, color: '444444' })]
        })
      );
      if (ana) {
        ana.split('\n').forEach((line) => {
          const t = line.trim();
          if (!t) return;
          out.push(textPara(t, { indent: { left: 360 }, color: '555555' }));
        });
      } else {
        out.push(
          new Paragraph({
            spacing: { before: 10, after: 10 },
            indent: { left: 360 },
            children: [new TextRun({ text: '（页面未提供，复习时可自行补充）', color: 'AAAAAA', size: 18 })]
          })
        );
      }
    }
    return out;
  }

  /**
   * 生成 docx Blob
   * @param {Array} questions
   * @param {Object} opt {title, subtitle, withAnswer, withAnalysis, onlyWrong}
   */
  NS.buildDocx = async function (questions, opt) {
    const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, Footer, PageNumber } = D();
    opt = opt || {};
    const withAnswer = opt.withAnswer !== false;
    const withAnalysis = opt.withAnalysis !== false;
    const onlyWrong = !!opt.onlyWrong;

    let list = questions.slice();
    if (onlyWrong) list = list.filter((q) => judge(q.myAnswer, q.answer, q.type) === 'wrong');

    const children = [];
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 120 },
        children: [new TextRun({ text: opt.title || '学习通试卷复习', bold: true, size: 36 })]
      })
    );
    if (opt.subtitle) {
      children.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { after: 240 },
          children: [new TextRun({ text: opt.subtitle, color: '666666', size: 20 })]
        })
      );
    }

    // 统计
    const total = list.length;
    const wrong = list.filter((q) => judge(q.myAnswer, q.answer, q.type) === 'wrong').length;
    const noAnalysis = list.filter((q) => !q.analysis).length;
    children.push(
      new Paragraph({
        spacing: { after: 120 },
        children: [
          new TextRun({
            text: `共 ${total} 题` + (onlyWrong ? '（仅错题）' : '') + (wrong ? `，其中答错 ${wrong} 题` : '') + (noAnalysis ? `，${noAnalysis} 题无解析` : ''),
            color: '666666',
            size: 20
          })
        ]
      })
    );

    // 按题型分节
    const groups = new Map();
    list.forEach((q) => {
      const k = q.type || '其他';
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k).push(q);
    });
    let idx = 0;
    for (const [type, arr] of groups) {
      children.push(
        new Paragraph({
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 300, after: 120 },
          children: [new TextRun({ text: `${type}（${arr.length} 题）`, bold: true, size: 28, color: '1F3864' })]
        })
      );
      for (const q of arr) {
        idx++;
        questionParas(q, idx, withAnswer, withAnalysis).forEach((p) => children.push(p));
      }
    }

    const doc = new Document({
      creator: '学习通试卷导出',
      title: opt.title || '学习通试卷复习',
      styles: {
        default: {
          document: { run: { font: '微软雅黑', size: 21 } }
        }
      },
      sections: [
        {
          properties: { page: { margin: { top: 1000, bottom: 1000, left: 1000, right: 1000 } } },
          footers: {
            default: new Footer({
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  children: [new TextRun({ children: ['第 ', PageNumber.CURRENT, ' 页 / 共 ', PageNumber.TOTAL_PAGES, ' 页'], size: 18, color: '888888' })]
                })
              ]
            })
          },
          children
        }
      ]
    });

    const blob = await Packer.toBlob(doc);
    return blob;
  };
})();
