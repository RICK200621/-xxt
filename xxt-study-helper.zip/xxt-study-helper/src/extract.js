/* 题目抽取核心：多套选择器 + 启发式兜底 + 语义分析 */
(function () {
  const NS = (globalThis.xxtHelper = globalThis.xxtHelper || {});
  if (NS.extract) return;

  const clean = NS.clean;
  const oneLine = NS.oneLine;
  const stripNum = NS.stripLeadingNumber;

  /* ---------------- 常量 ---------------- */

  const TYPE_RANK = {
    单选题: 1, 多选题: 2, 判断题: 3, 填空题: 4, 简答题: 5, 名词解释: 6,
    论述题: 7, 计算题: 8, 分析题: 9, 匹配题: 10, 其他: 99
  };

  const TYPE_KEYS = [
    ['名词解释', '名词解释'], ['简答', '简答题'], ['论述', '论述题'], ['计算', '计算题'],
    ['分析', '分析题'], ['判断', '判断题'], ['填空', '填空题'], ['匹配', '匹配题'],
    ['多选', '多选题'], ['单选', '单选题'], ['选择', '单选题']
  ];

  // 题干开头的题型标记，如 "1.（单选题）xxx" / "第1题(多选题): xxx" / "(单选题, 4.0 分) xxx"
  // 学习通复习页的题型标记写成 "(单选题, 4.0 分)"，括号内可能带分值。
  // 关键：题型名必须紧跟在括号后，不能先吃掉括号再匹配题型名（否则 "(单选题" 里的 "(" 被当分隔符，题型名匹配失败）。
  const STEM_PREFIX = new RegExp(
    '^\\s*(?:第\\s*\\d+\\s*题\\s*)?' +
      '(?:[（(【\\[]\\s*)?' +
      '(?:单项选择|多项选择|不定项选择|单选题|多选题|判断题|填空题|简答题|名词解释|论述题|计算题|分析题|匹配题|选择题)' +
      '(?:\\s*[,，、;；]?\\s*[\\d.]+\\s*分)?' +
      '\\s*(?:[）)】\\]]|$|[.、:：])'
  );

  // 独立成段的噪音行
  const NOISE_LINE = /^(答案|正确答案|参考答案|你的答案|我的答案|考生答案|学生答案|解析|答案解析|本题答案|回答正确|回答错误|答对|答错|正确|错误|得分|本题得分|所属章节|知识点|视频解析|图片解析|收起|展开)$/i;
  const NOISE_PREFIX = /^(答案|正确答案|参考答案|你的答案|我的答案|考生答案|学生答案|解析|答案解析|本题答案|视频解析)/;

  const SEARCH_ANY = 'input[type=radio],input[type=checkbox]';

  const doc = document;

  /* ---------------- 基础工具 ---------------- */

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const st = getComputedStyle(el);
    if (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
    if (st.position === 'fixed' && /translate\(-?[1-9]\d{2,}px/.test(st.transform || '')) return false;
    // 无头环境（jsdom 等）没有布局引擎，退化成只看样式
    if (!nativeLayout) return true;
    const r = el.getBoundingClientRect();
    return r.width > 0 || r.height > 0;
  }

  // 探测浏览器能否真正布局
  const nativeLayout = (() => {
    try {
      const probe = document.createElement('div');
      probe.style.cssText = 'position:absolute;left:-9999px;top:0;width:10px;height:10px';
      (document.body || document.documentElement).appendChild(probe);
      const ok = probe.getBoundingClientRect().width > 0;
      probe.remove();
      return ok;
    } catch (e) {
      return true;
    }
  })();

  function txt(el) {
    return el ? clean(el.innerText || el.textContent || '') : '';
  }

  function closestAny(el, sels, maxDepth) {
    let node = el;
    let d = 0;
    while (node && node !== doc.body && d < (maxDepth || 12)) {
      for (const s of sels) {
        try { if (node.matches && node.matches(s)) return node; } catch (e) { /* 跳过不支持的选择器 */ }
      }
      node = node.parentElement;
      d++;
    }
    return null;
  }

  function nextTextSibling(el) {
    let n = el.nextSibling, steps = 0;
    while (n && steps < 3) {
      steps++;
      if (n.nodeType === 1) { const t = txt(n); if (t) return t; }
      else if (n.nodeType === 3) { const t = clean(n.nodeValue); if (t) return t; }
      n = n.nextSibling;
    }
    return '';
  }

  /* ---------------- 结构化字段读取 ---------------- */

  /** 按"标签：值"抽字段（标签可能在独立元素里，也可能在纯文本行里） */
  function readLabeledText(root, labels) {
    const nodes = root.querySelectorAll('span,a,div,p,em,strong,b,i,font,li,dt,dd,label,td,th');
    for (const n of nodes) {
      if (!isVisible(n)) continue;
      const t = clean(n.textContent);
      if (t.length > 40) continue;
      for (const lb of labels) {
        const m = t.match(new RegExp('^' + lb + '\\s*[：:]\\s*(.*)$'));
        if (!m) continue;
        let val = m[1].trim();
        if (!val) val = nextTextSibling(n).split('\n')[0];
        if (!val) {
          const p = n.parentElement;
          if (p) {
            const pt = txt(p);
            const idx = pt.indexOf(lb);
            if (idx >= 0) val = pt.slice(idx + lb.length).replace(/^[\s:：]+/, '').split('\n')[0];
          }
        }
        if (val) return val;
      }
    }
    const raw = (root.innerText || '').split('\n');
    for (const line of raw) {
      const t = clean(line);
      for (const lb of labels) {
        const m = t.match(new RegExp('^' + lb + '\\s*[：:]\\s*(.+)$'));
        if (m) return m[1].trim();
      }
    }
    return '';
  }

  /** 读取被勾选/标记正确的选项 */
  function readCheckedOptions(root) {
    const res = [];
    root.querySelectorAll(SEARCH_ANY).forEach((inp) => {
      if (!inp.checked) return;
      const wrap = closestAny(inp, ['li', 'label', '[data-key]', '[data-index]', '.answerList', '.option', '.item', 'tr'], 6) || inp.parentElement;
      res.push({ key: guessOptionKey(wrap || inp), text: wrap ? optionText(wrap) : '' });
    });
    if (res.length) return res;
    root.querySelectorAll('*').forEach((el) => {
      if (el.children.length > 2) return;
      const t = clean(el.textContent);
      if (/^(对的|错的|正确|错误|√|✓|×|✗|对|错)$/.test(t)) return;
      const cl = (el.getAttribute('class') || '') + ' ' + (el.getAttribute('src') || '');
      let wrong = false;
      if (/(right|correct|dui|success)/i.test(cl)) wrong = false;
      else if (/(wrong|error|cuo|fail)/i.test(cl)) wrong = true;
      else return;
      const wrap = closestAny(el, ['li', 'label', '[data-key]', '.answerList', '.option', '.item'], 6);
      if (wrap) res.push({ key: guessOptionKey(wrap, el), text: optionText(wrap), wrong });
    });
    return res.filter((r) => !r.wrong);
  }

  function optionText(wrap) {
    if (!wrap) return '';
    const cl = wrap.cloneNode(true);
    cl.querySelectorAll('input,img,i,em,span[class*="icon"],[class*="dui"],[class*="check"],[class*="num_option"],[class*="Option"]').forEach((n) => {
      const t = clean(n.textContent);
      if (/^[A-J]\s*[.、:：)）]?$/i.test(t) || t.length <= 1) n.remove();
    });
    // 选项区整体文本去掉开头的字母标号（只去掉第一个，避免把 IP 误伤成 P）
    let t = clean(cl.innerText || cl.textContent || '');
    t = t.replace(/^(?:[（(\[]?\s*[A-Ja-j]\s*[）)\].、:：]\s*|[A-Ja-j]\s*[.、:：]\s*)/, '');
    return clean(t);
  }

  function guessOptionKey(wrap, altEl) {
    if (!wrap) return '';
    for (const s of ['[data-key]', '[data-index]', '[data-value]', 'input']) {
      const el = wrap.matches(s) ? wrap : wrap.querySelector(s);
      if (el) {
        const v = el.getAttribute('data-key') || el.getAttribute('data-index') || el.getAttribute('data-value') || el.value;
        if (v != null && String(v).trim()) return String(v).trim();
      }
    }
    if (altEl) {
      const v = altEl.getAttribute('data-key');
      if (v) return v;
    }
    const t = clean((wrap.innerText || '').slice(0, 6));
    const m = t.match(/^[（(\[]?\s*([A-Ja-j])\s*[）)\].、:：]/) || t.match(/^([A-Ja-j])\b/);
    return m ? m[1].toUpperCase() : '';
  }

  /* ---------------- 题干分析 ---------------- */

  function stripStem(s) {
    let t = clean(s);
    let type = '';
    const num = stripNum(t);
    let rest = num.text;
    const m = rest.match(STEM_PREFIX);
    if (m) {
      const inside = m[0].match(/单项选择|多项选择|不定项选择|单选|多选|选择|判断|填空|简答|名词解释|论述|计算|分析|匹配/);
      if (inside) type = TYPE_KEYS.find(([k]) => inside[0].includes(k))?.[1] || '';
      rest = rest.slice(m[0].length);
    }
    rest = rest
      .split('\n')
      .filter((line) => !NOISE_PREFIX.test(clean(line)))
      .join('\n');
    return { stem: clean(rest), type, num: num.num };
  }

  function normType(s) {
    if (!s) return '';
    for (const [k, v] of TYPE_KEYS) if (s.includes(k)) return v;
    return '';
  }

  const LETTER_ONLY = /^[A-J](?:[\s,，、]*[A-J]){0,9}$/;

  function normAnswer(ans, options, type) {
    let a = clean(ans || '');
    if (!a) return '';
    a = a.replace(/^[：:\s]+/, '');
    a = a.replace(/^(你的答案|我的答案|考生答案|学生答案|正确答案|参考答案|答案)\s*[：:]?\s*/, '');
    if (LETTER_ONLY.test(a.replace(/\s+/g, ' '))) {
      return [...new Set(a.match(/[A-J]/g) || [])].sort().join('');
    }
    if (options && options.length) {
      const norm = (s) => clean(s).replace(/\s+/g, '').replace(/[，,。.]/g, '');
      const hits = options.filter((o) => {
        const ao = norm(o.text), av = norm(a);
        return ao && (ao === av || (ao.length > 1 && av.includes(ao)));
      });
      if (hits.length && hits.length <= Math.max(1, Math.floor(options.length / 2) + 1)) {
        if (hits.length === 1 && /单选题|判断题/.test(type || '')) return hits[0].key || '';
        return [...new Set(hits.map((o) => o.key))].filter(Boolean).sort().join('');
      }
    }
    return a;
  }

  /* ---------------- 判定 ---------------- */

  function judge(myAnswer, answer, type) {
    const norm = (s) => clean(s || '').replace(/\s+/g, '').replace(/[，,。.；;、：:]/g, '').toUpperCase();
    const a = norm(myAnswer), b = norm(answer);
    if (!a || !b) return '';
    if (a === b) return 'correct';
    const ja = a.replace(/正确的|对|√|✓|TRUE/g, '√').replace(/错误的|错|×|✗|FALSE/g, '×');
    const jb = b.replace(/正确的|对|√|✓|TRUE/g, '√').replace(/错误的|错|×|✗|FALSE/g, '×');
    if (ja === jb) return 'correct';
    const letters = (s) => [...new Set(s.match(/[A-J]/g) || [])].sort().join('');
    if (letters(a) && letters(a) === letters(b)) return 'correct';
    return 'wrong';
  }

  /** 学习通复习页：直接从专用 class 取我的答案 / 正确答案 / 解析 */
  function readChaoxingFields(root) {
    const pick = (sels) => {
      for (const s of sels) {
        const el = root.querySelector(s);
        if (el) {
          const t = clean(el.innerText || el.textContent || '');
          if (t) return t;
        }
      }
      return '';
    };
    return {
      my: pick(['.stuAnswerContent', '.myAnswerContent', '[class*="stuAnswer"]', '[class*="myAnswer"]']),
      answer: pick(['.rightAnswerContent', '[class*="rightAnswer"]', '[class*="correctAnswer"]', '[class*="trueAnswer"]']),
      analysis: pick(['.qtAnalysis', '[class*="qtAnalysis"]', '[class*="analysisContent"]', '[class*="Analysis"]'])
    };
  }

  /* ---------------- 选项提取 ---------------- */

  const OPTION_WRAP_SEL = ['[data-key][data-index]', 'label', 'li', '.item', '.option', '.answer', 'dd', 'tr'];

  function findOptionWraps(root) {
    let wraps = [];
    for (const s of OPTION_WRAP_SEL) {
      try {
        const found = [...root.querySelectorAll(s)].filter(
          (el) => isVisible(el) && !el.querySelector(SEARCH_ANY + ',img,table,ul,dl')
        );
        if (found.length >= 2) { wraps = found; break; }
      } catch (e) { /* ignore */ }
    }
    if (!wraps.length) {
      const cand = [...root.querySelectorAll('div,span,p')].filter((el) => {
        if (el.children.length > 3) return false;
        const t = oneLine(el.innerText || el.textContent || '');
        return t.length > 0 && t.length < 400 && /^[（(\[]?\s*[A-J]\s*[）)\].、:：]/.test(t);
      });
      wraps = cand.filter((el) => !cand.some((o) => o !== el && el.contains(o)));
    }
    return wraps;
  }

  function readOptions(root) {
    const wraps = findOptionWraps(root).slice(0, 15);
    const opts = [];
    for (const w of wraps) {
      let key = guessOptionKey(w);
      const text = optionText(w);
      if (!key || !/^[A-J]$/i.test(key)) {
        const m = oneLine(w.innerText || w.textContent || '').match(/^[（(\[]?\s*([A-J])\s*[）)\].、:：]?/);
        if (m) key = m[1].toUpperCase();
        else if (opts.length < 10) key = String.fromCharCode(65 + opts.length);
        else continue;
      }
      key = key.toUpperCase();
      if (!text) continue;
      if (opts.some((o) => o.key === key)) continue;
      opts.push({ key, text: text.replace(/^(?:[（(\[]?\s*[A-J]\s*[）)\].、:：]\s*|[A-J]\s*[.、:：]\s*)/, '').trim() });
    }
    return opts.filter((o) => o.text);
  }

  /* ---------------- 主抽取 ---------------- */

  const CONTAINER_SELS = [
    '.questionLi', '.question-item', '.questionItem', '.mark_item', '.TiMu', '.AiTiMu',
    '[data-questionid]', '[data-question-id]', '.subject', '.queBox', '.question',
    '.topic-item', '.ti-item', '.singleQuesId'
  ];

  NS.extractFrom = function (scope) {
    scope = scope || doc.body;
    let best = null;
    for (const sel of CONTAINER_SELS) {
      let els = [];
      try {
        els = [...scope.querySelectorAll(sel)].filter(isVisible);
        if (/data-/.test(sel)) {
          els = els.filter((el) => {
            if (el.querySelector(SEARCH_ANY)) return true;
            const t = (el.innerText || '').slice(0, 3000);
            return /(正确答案|参考答案|你的答案|解析)/.test(t) && /[?？]/.test(t);
          });
        }
      } catch (e) { continue; }
      if (!els.length) continue;
      els = els.filter((el) => !els.some((o) => o !== el && o.contains(el)));
      const parsed = els.map((el, i) => {
        try {
          return parseContainer(el, i + 1);
        } catch (err) {
          return null;
        }
      }).filter((q) => q && q.stem);
      if (parsed.length > (best ? best.length : 0)) best = parsed;
    }
    if (best && best.length) return finalize(best);
    return finalize(heuristicBlocks(scope));
  };

  function parseContainer(el, index) {
    const rawId = el.getAttribute('data-questionid') || el.getAttribute('data-question-id') || el.getAttribute('data-id') || el.id || '';
    let typeText = '';
    const tagEl = el.querySelector('.newZy_TItle, .qtType, [class*="type"], [class*="Type"], .questionType, .font-label');
    if (tagEl) typeText = oneLine(tagEl.textContent).slice(0, 20);

    // 先剥掉选项区，避免选项混进题干
    const optZoneSel = '.answerList, .optionList, .answer_list, [class*="option"], [class*="answerList"], ul.list, dl';
    const cl = el.cloneNode(true);
    if (el.querySelector(optZoneSel)) {
      cl.querySelectorAll(optZoneSel).forEach((n) => n.remove());
    }
    let stemRaw = '';
    const stemEl = cl.querySelector('.mark_name, .stem, .questionStem, .question-content, .Zy_TItle, h1, h2, h3, .title');
    if (stemEl) stemRaw = txt(stemEl);
    if (!stemRaw) {
      stemRaw = (cl.innerText || '')
        .split('\n')
        .filter((l) => {
          const t = clean(l);
          if (!t) return false;
          if (NOISE_LINE.test(t.replace(/[：:].*$/, ''))) return false;
          if (NOISE_PREFIX.test(t)) return false;
          return true;
        })
        .join('\n');
    }
    const analyzed = stripStem(stemRaw);
    const options = readOptions(el);

    const cx = readChaoxingFields(el);
    const myRaw = cx.my || readLabeledText(el, ['你的答案', '我的答案', '考生答案', '学生答案']);
    const ansRaw = cx.answer || readLabeledText(el, ['正确答案', '参考答案', '答案']);
    const analysisRaw = cx.analysis || readLabeledText(el, ['解析', '答案解析', '本题解析']);

    let answer = ansRaw;
    if (!answer) {
      const checked = readCheckedOptions(el);
      if (checked.length) {
        answer = checked.map((c) => c.key).filter(Boolean).join('');
        if (!answer) answer = checked.map((c) => c.text).join('；');
      }
    }

    const type = normType(typeText) || analyzed.type || guessType(options, answer);
    const myAnswer = normAnswer(myRaw, options, type);
    const finalAnswer = normAnswer(answer, options, type);

    if (!analyzed.stem && !options.length) return null;
    if (options.length === 1) return null;

    return {
      index: typeof analyzed.num === 'number' ? analyzed.num : index,
      rawId: String(rawId).replace(/^question/i, '') || '',
      type,
      typeRank: TYPE_RANK[type] || 99,
      stem: analyzed.stem || stemRaw,
      options,
      myAnswer,
      answer: finalAnswer,
      analysis: clean(analysisRaw),
      sourceUrl: location.href,
      sourceTitle: doc.title
    };
  }

  function guessType(options, answer) {
    const a = clean(answer);
    if (!options || !options.length) {
      return /[√×✓✗]|^对$|^错$|正确|错误/.test(a) ? '判断题' : '其他';
    }
    if (LETTER_ONLY.test(a)) return a.length > 2 ? '多选题' : '单选题';
    return '单选题';
  }

  /** 兜底：无结构化 class 时，按"我的答案/正确答案/你的答案"锚点切块 */
  const HEUR_TAGS = 'p,div,li,dd,dt,h1,h2,h3,h4,h5,h6,td,tr,section,article,label,b,strong,font,span';
  // 答案类锚点：解析行不算（否则"正确答案"+"解析"会粘成一组）
  const HEUR_ANCHOR = /^(正确答案|参考答案|我的答案|你的答案|考生答案|学生答案|答案)\s*[：:]/;
  // 任意题目边界标记：锚点或解析行
  const HEUR_BOUNDARY = /^(正确答案|参考答案|我的答案|你的答案|考生答案|学生答案|答案|解析|答案解析|本题解析|试题解析)\s*[：:]/;

  /** 兜底核心：把整页可见文本行切成"题目" */
  function heuristicBlocks(scope) {
    // 只取"叶子行"：不再包含其它语义行的元素，避免把整块当一行
    const leaf = [...scope.querySelectorAll(HEUR_TAGS)].filter((el) => {
      if (!isVisible(el)) return false;
      return !el.querySelector('p,div,li,td,tr,dt,dd,table,ul,ol,section,article');
    });

    const lines = [];
    for (const el of leaf) {
      const t = oneLine(el.innerText || el.textContent || '');
      if (!t || t.length > 4000) continue;
      lines.push({ el, t });
    }

    // 1) 找题干起点：优先"第N题"/"1."这种带题号的行，退化到所有题干行
    const numbered = [];
    const anyStem = [];
    lines.forEach((ln, i) => {
      const t = ln.t;
      if (HEUR_ANCHOR.test(t) || HEUR_BOUNDARY.test(t)) return;
      if (/^第\s*\d+\s*题/.test(t) || /^\d+\s*[.、．)）](?!\d)/.test(t)) numbered.push(i);
      else if (/【(单选|多选|判断|填空|不定项)/.test(t)) numbered.push(i);
      anyStem.push(i);
    });
    const starts = numbered.length >= 2 ? numbered : anyStem;

    // 2) 按起点切块；没有起点就用整块
    const segs = [];
    if (starts.length >= 1) {
      for (let k = 0; k < starts.length; k++) {
        const from = starts[k];
        const to = k + 1 < starts.length ? starts[k + 1] : lines.length;
        segs.push(lines.slice(from, to));
      }
    } else {
      segs.push(lines.slice());
    }

    // 3) 一块里如果有多个锚点组，按锚点相邻性再切一次
    const out = [];
    let idx = 0;
    for (const seg of segs) {
      // 块内第一个锚点之前的部分是题干/选项
      const firstAnchor = seg.findIndex((ln) => HEUR_ANCHOR.test(ln.t));
      if (firstAnchor < 0) continue;
      // 若块里还有第二个"我的答案/你的答案"锚点，说明切得不够，忽略（由起点兜住）
      const q = buildFromLines(seg, firstAnchor, ++idx);
      if (q && q.stem) out.push(q);
    }
    return out;
  }

  /** 从一段行里组装题目 */
  function buildFromLines(seg, firstAnchor, index) {
    const before = seg.slice(0, firstAnchor);
    const after = seg.slice(firstAnchor);

    // ---- 题干 + 选项 ----
    const stemLines = [];
    const optLines = [];
    for (const ln of before) {
      const t = ln.t;
      if (NOISE_PREFIX.test(t) || HEUR_BOUNDARY.test(t)) continue;
      if (/^[（(\[]?\s*[A-J]\s*[）)\].、:：]\s*\S/.test(t)) optLines.push(t);
      else stemLines.push(t);
    }
    let stemRaw = oneLine(stemLines.join(' '));
    if (!optLines.length) {
      const m = stemRaw.match(/[ \u3000\u00a0](?=[A-J][.、:：]\s*\S)/);
      if (m) {
        optLines.push(
          ...stemRaw
            .slice(m.index)
            .split(/[ \u3000\u00a0](?=[A-J][.、:：])/)
            .map((s) => s.trim())
            .filter(Boolean)
        );
        stemRaw = stemRaw.slice(0, m.index);
      }
    }
    const analyzed = stripStem(stemRaw);
    const options = [];
    for (const line of optLines) {
      const m = line.match(/^[（(\[]?\s*([A-J])\s*[）)\].、:：]\s*(.*)$/);
      if (!m) continue;
      if (options.some((o) => o.key === m[1])) continue;
      options.push({ key: m[1].toUpperCase(), text: clean(m[2]) });
    }

    // ---- 答案 + 解析 ----
    // 每段单独记，续行只在对应段"还没值"时拼接，避免互相串题
    let myRaw = '';
    let ansRaw = '';
    let analysisRaw = '';
    let mode = '';
    let modeTouched = false;
    for (const { t } of after) {
      const m = t.match(/^(正确答案|参考答案|我的答案|你的答案|考生答案|学生答案|答案|解析|答案解析|本题解析|试题解析)\s*[：:]\s*(.*)$/);
      if (m) {
        const label = m[1];
        const val = clean(m[2]);
        if (/解析/.test(label)) {
          mode = 'analysis';
          if (!analysisRaw) analysisRaw = val;
        } else if (/我的|你的|考生|学生/.test(label)) {
          mode = 'mine';
          if (!myRaw) myRaw = val;
        } else {
          mode = 'answer';
          if (!ansRaw) ansRaw = val;
        }
        modeTouched = !val; // 标签后没值，下一行是续行
        continue;
      }
      // 续行：只在紧跟着标签且该段还没内容时拼接
      if (!modeTouched) {
        mode = 'done';
        continue;
      }
      if (mode === 'analysis') analysisRaw = oneLine(analysisRaw + ' ' + t);
      else if (mode === 'mine') myRaw = t;
      else if (mode === 'answer') ansRaw = t;
      modeTouched = false;
    }

    if (!analyzed.stem && !options.length) return null;
    const type = analyzed.type || guessType(options, ansRaw);
    const stem = (analyzed.stem || stemRaw).slice(0, 4000);
    if (!stem) return null;
    return {
      index: typeof analyzed.num === 'number' ? analyzed.num : index,
      rawId: '',
      type,
      typeRank: TYPE_RANK[type] || 99,
      stem,
      options,
      myAnswer: normAnswer(myRaw, options, type),
      answer: normAnswer(ansRaw, options, type),
      analysis: clean(analysisRaw),
      sourceUrl: location.href,
      sourceTitle: doc.title
    };
  }

  function finalize(list) {
    const seen = new Set();
    const out = [];
    for (const q of list) {
      q.stem = clean(q.stem).slice(0, 4000);
      q.analysis = clean(q.analysis).slice(0, 20000);
      q.myAnswer = clean(q.myAnswer);
      q.answer = clean(q.answer);
      q.stem = q.stem
        .split('\n')
        .filter((l) => !NOISE_PREFIX.test(clean(l)))
        .join('\n')
        .trim();
      if (!q.stem) continue;
      // 去重键：题干 + 答案 + 我的答案 + 选项全文。
      // 学习通作业里常有"题干相同但选项数不同"的同源题（如"对待马克思主义,必须"出现3次，选项 4/4/3 个），
      // 只按题干去重会把它们误删，所以必须把选项一起算进去。
      const optKey = (q.options || []).map((o) => o.key + o.text).join('|');
      const k = q.stem.slice(0, 80) + '#' + q.answer + '#' + q.myAnswer + '#' + optKey;
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(q);
    }
    return out;
  }

  NS.looksLikeExamPage = function () {
    try {
      const t = (document.title || '') + oneLine((document.body ? document.body.innerText : '').slice(0, 3000));
      return /(正确答案|参考答案|你的答案|考试|测验|作业|试卷|答题|交卷|批阅|成绩|得分|解析)/.test(t);
    } catch (e) {
      return false;
    }
  };

  NS.judge = judge;
  NS.normAnswer = normAnswer;
  /**
   * 抓不到题时用来自查：看是哪一步断了。
   * 返回 { version, bodyLen, links: [[选择器, 命中数]], blocks, parsed, hint }
   */
  NS.diagnose = function (scope) {
    scope = scope || doc.body;
    const bodyLen = scope ? oneLine(scope.innerText || scope.textContent || '').length : 0;
    const links = [];
    for (const sel of CONTAINER_SELS) {
      let n = 0;
      try { n = scope.querySelectorAll(sel).length; } catch (e) { n = -1; }
      if (n > 0) links.push([sel, n]);
    }
    let total = 0;
    try { total = (NS.extractFrom(scope) || []).length; } catch (e) { /* ignore */ }
    let hint = '';
    if (!links.length) {
      hint = bodyLen < 200
        ? '页面几乎是空的，可能还没加载完 / 需要登录 / 内容在 iframe 里没被读到'
        : '没认出任一题目容器，页面结构不在已知范围内';
    } else if (!total) {
      hint = '认出了题目容器但解析不出字段，可能是页面结构变了';
    }
    return {
      version: NS.VERSION || '?',
      url: location.href,
      bodyLen: bodyLen,
      links: links,
      parsed: total,
      hint: hint,
      frames: window.top === window ? 'top' : 'iframe'
    };
  };

  NS.extract = true;
})();