(function () {
  const out = [];
  out.push('---- 所有 <a> 文本 + onclick ----');
  const seen = new Set();
  [...document.querySelectorAll('a')].forEach((a) => {
    const t = (a.innerText || '').trim().replace(/\s+/g, ' ');
    const oc = a.getAttribute('onclick') || '';
    const key = t + '|' + oc;
    if (seen.has(key)) return;
    seen.add(key);
    if (!t && !oc) return;
    out.push(JSON.stringify(t) + ' | onclick=' + oc.slice(0, 150) + ' | cls=' + (typeof a.className === 'string' ? a.className : ''));
  });
  out.push('---- 页头区域 HTML ----');
  const head = document.querySelector('.examHead, .title, #content') || document.body;
  out.push((head.outerHTML || '').slice(0, 2500));
  return out.join('\n');
})();
