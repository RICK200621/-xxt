(function () {
  const out = [];
  const ql = [...document.querySelectorAll('.questionLi')];
  out.push('count: ' + ql.length);
  out.push('---- 每题的 HTML 特征 ----');
  ql.forEach((q, i) => {
    const h = q.outerHTML;
    out.push(
      i + 1 +
      ' | len=' + h.length +
      ' | mark_name=' + q.querySelectorAll('.mark_name').length +
      ' | mark_letter=' + q.querySelectorAll('.mark_letter').length +
      ' | li=' + q.querySelectorAll('li').length +
      ' | has正确答案=' + /正确答案|参考答案/.test(h) +
      ' | has解析=' + /解析/.test(h) +
      ' | has我的答案=' + /我的答案|你的答案/.test(h) +
      ' | classes=' + [...q.querySelectorAll('[class]')].map((e) => e.className).filter((c) => typeof c === 'string').join(',').slice(0, 300)
    );
  });
  out.push('---- 页面里是否有展开按钮 ----');
  const btns = [...document.querySelectorAll('a,button,div[onclick],span[onclick]')].filter((e) => /答案|解析|展开|查看/.test(e.innerText || ''));
  btns.slice(0, 20).forEach((e) => out.push(e.tagName + ' | ' + (e.className || '') + ' | ' + JSON.stringify((e.innerText || '').slice(0, 40))));
  return out.join('\n');
})();
