(function () {
  const NS = window.xxtHelper;
  const qs = NS.extractFrom(document.body);
  const stat = { total: qs.length, noOpt: 0, noMy: 0, noAns: 0, noAna: 0, dirty: 0 };
  const types = {};
  qs.forEach(function (q) {
    if (!q.options || q.options.length < 2) stat.noOpt++;
    if (!q.myAnswer) stat.noMy++;
    if (!q.answer) stat.noAns++;
    if (!q.analysis) stat.noAna++;
    if (/[;；]|^[:：]/.test(q.answer || '') || /[;；]|^[:：]/.test(q.myAnswer || '')) stat.dirty++;
    types[q.type || '?'] = (types[q.type || '?'] || 0) + 1;
  });
  return JSON.stringify({ stat: stat, types: types }, null, 2);
})();
