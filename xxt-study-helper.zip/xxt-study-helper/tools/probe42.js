(function () {
  const out = [];
  // 通过重新执行 extract.js 源码来拿到内部函数：
  // 在页面里 eval 时，函数闭包里的 parseContainer 拿不到。
  // 换法子：给 extractFrom 传一个只包含该块的容器，但让 DOM 结构完整（不 clone）
  // 之前的测试用了 clone + wrap，可能 clone 改变了什么。这次直接传原始父节点。

  const el = document.getElementById('question214104388');
  const parent = el.parentElement;
  out.push('父节点: ' + parent.tagName + '.' + parent.className);

  const viaParent = window.xxtHelper.extractFrom(parent);
  out.push('父容器 extractFrom=' + viaParent.length + ' 含38=' + viaParent.some(function (q) { return String(q.rawId) === '214104388'; }));

  // 直接提取该块所在的 .mark_item 之类
  const all = window.xxtHelper.extractFrom(document.body);
  out.push('整页=' + all.length);

  // 逐个把块放进独立容器，看哪些失败
  const fails = [];
  const blocks = [...document.querySelectorAll('.questionLi')];
  blocks.forEach(function (b, i) {
    const w = document.createElement('div');
    document.body.appendChild(w);
    w.appendChild(b.cloneNode(true));
    const got = window.xxtHelper.extractFrom(w);
    if (got.length !== 1) fails.push({ i: i, id: b.getAttribute('data'), got: got.length });
    w.remove();
  });
  out.push('单独抽取失败的块数=' + fails.length);
  out.push(JSON.stringify(fails));
  return out.join('\n');
})();
