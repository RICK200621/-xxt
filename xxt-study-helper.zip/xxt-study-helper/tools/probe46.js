(function () {
  const out = [];
  const NS = window.xxtHelper;
  const scope = document.body;

  // 直接跑 .questionLi 这一条选择器链，看每步剩多少
  let els = [...scope.querySelectorAll('.questionLi')];
  out.push('原始 .questionLi = ' + els.length);

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const st = getComputedStyle(el);
    if (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
    if (st.position === 'fixed' && /translate\(-?[1-9]\d{2,}px/.test(st.transform || '')) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 || r.height > 0;
  }

  let visible = els.filter(isVisible);
  out.push('isVisible 后 = ' + visible.length);
  const inv = els.filter(function (e) { return !isVisible(e); });
  out.push('不可见的 id: ' + inv.map(function (e) { return e.getAttribute('data') + '(' + getComputedStyle(e).display + ')'; }).join(', '));

  let noNest = visible.filter(function (el) { return !visible.some(function (o) { return o !== el && o.contains(el); }); });
  out.push('去嵌套后 = ' + noNest.length);
  return out.join('\n');
})();
