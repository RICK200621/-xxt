(function () {
  const out = [];
  const ql = document.querySelectorAll('.questionLi');
  out.push('questionLi count: ' + ql.length);
  const first = ql[0];
  out.push('---- 第1题的 outerHTML（前 3000 字符）----');
  out.push(first.outerHTML.slice(0, 3000));
  out.push('---- 第1题的 innerText ----');
  out.push(JSON.stringify(first.innerText));
  return out.join('\n');
})();
