(function () {
  const out = [];
  const ids = ['214104388', '214104410', '214104413', '214104438', '214104449', '214104451', '214104457'];

  // 抓取 readOptions 的结果：用 clone 单独跑一次 extractFrom 得到的 opts，再看整页时的行为
  // 关键是看 readOptions 会不会因为页面里其它元素而改变行为

  // 先看这些块里 li 的 class 和其它块有什么不同
  out.push('==== 缺失块的 li class 对比 ====');
  const okEl = document.getElementById('question214104351');
  out.push('正常块 #1 li: ' + [...okEl.querySelectorAll('.mark_letter li')].map(function (l) { return JSON.stringify(l.className); }).join(' '));
  ids.slice(0, 3).forEach(function (id) {
    const el = document.getElementById('question' + id);
    if (!el) { out.push(id + ' 不存在'); return; }
    out.push(id + ' li: ' + [...el.querySelectorAll('.mark_letter li')].map(function (l) { return JSON.stringify(l.className); }).join(' '));
    out.push('   mark_letter 存在=' + !!el.querySelector('.mark_letter') + '  ul 数=' + el.querySelectorAll('ul').length);
  });

  // 检查 [class*="option"] / dl 选择器会不会把 mark_letter 里的东西删掉
  out.push('\n==== 各块 optZoneSel 命中 ====');
  const optZoneSel = '.answerList, .optionList, .answer_list, [class*="option"], [class*="answerList"], ul.list, dl';
  [okEl, document.getElementById('question214104388')].forEach(function (el, i) {
    if (!el) return;
    const hit = [...el.querySelectorAll(optZoneSel)];
    out.push('  块' + (i === 0 ? '#1(正常)' : '#38(缺失)') + ' 命中 ' + hit.length + ' 个: ' + hit.map(function (h) { return h.tagName + '.' + h.className; }).join(' | '));
  });
  return out.join('\n');
})();
