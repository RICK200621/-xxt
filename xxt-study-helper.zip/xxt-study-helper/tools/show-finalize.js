const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'src', 'extract.js'), 'utf8');

// 取出 finalize 函数体，检查去重逻辑
const i = src.indexOf('function finalize(list)');
console.log(src.slice(i, i + 1200));
