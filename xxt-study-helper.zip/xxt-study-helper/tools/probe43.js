(function () {
  const out = [];
  // 截获 parseContainer 抛的异常：包装 Array.prototype.filter 没用，
  // 用 window.onerror 也拦不到同步 try/catch。
  // 换个思路：把 extract.js 源码重新 eval 一次，但把源码里的 parseContainer 包一层日志。

  // 从页面上拿不到源码文件，但从已注入的脚本里能拿到函数源码。
  // 用 XHR 读本地文件不行（CSP），所以改为在页面里 fetch 一次看看能不能读 dist
  // 实际做法：直接看 7 个块的 parse 关键字段差异 —— 分值！
  const ids = ['214104388', '214104410', '214104413', '214104438', '214104449', '214104451', '214104457'];
  const all = [...document.querySelectorAll('.questionLi')];
  out.push('==== 缺失块 vs 正常块：各字段对比 ====');

  function sig(el) {
    return {
      id: el.getAttribute('data'),
      qtContent: !!el.querySelector('.qtContent'),
      markName: !!el.querySelector('.mark_name'),
      markLetter: !!el.querySelector('.mark_letter'),
      li: el.querySelectorAll('.mark_letter li').length,
      markAnswer: !!el.querySelector('.mark_answer'),
      stuAns: (el.querySelector('.stuAnswerContent') || {}).innerText,
      rightAns: (el.querySelector('.rightAnswerContent') || {}).innerText,
      qtAnalysis: !!el.querySelector('.qtAnalysis'),
      analysis: !!el.querySelector('.analysis'),
      totalScore: (el.querySelector('.totalScore') || {}).innerText,
      aiAssistant: !!el.querySelector('.aiAssistant'),
      htmlLen: el.outerHTML.length
    };
  }
  out.push('正常 #1: ' + JSON.stringify(sig(all[0])));
  ids.forEach(function (id) {
    const el = all.find(function (x) { return x.getAttribute('data') === id; });
    if (el) out.push('缺失 ' + id + ': ' + JSON.stringify(sig(el)));
  });

  // 关键：看这些块的 .aiAreaContent 是否为空 / 是否也含 qtDetail
  out.push('\n==== 缺失块的 aiAreaContent 存在性 ====');
  ids.forEach(function (id) {
    const el = all.find(function (x) { return x.getAttribute('data') === id; });
    if (!el) return;
    out.push(id + ' aiArea=' + !!el.querySelector('.aiArea') + ' aiAreaContent=' + !!el.querySelector('.aiAreaContent') + ' qtDetail=' + !!el.querySelector('.qtDetail'));
  });
  return out.join('\n');
})();
