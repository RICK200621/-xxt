(function () {
  const out = [];
  const NS = window.xxtHelper;
  const all = [...document.querySelectorAll('.questionLi')];
  out.push('DOM 中 .questionLi 总数=' + all.length);

  // 逐块独立解析，找出哪 7 块没被抽出来
  const qs = NS.extractFrom(document.body);
  out.push('抽出=' + qs.length);

  // 用 rawId 比对
  const ids = new Set(qs.map(function (q) { return String(q.rawId); }));
  const missing = all.filter(function (el) {
    const id = el.getAttribute('data') || el.id.replace(/^question/, '');
    return !ids.has(String(id));
  });
  out.push('未抽出的块=' + missing.length);
  missing.slice(0, 8).forEach(function (el, i) {
    const id = el.getAttribute('data') || el.id;
    out.push('--- 缺失[' + i + '] id=' + id + ' ---');
    out.push('  innerText: ' + JSON.stringify((el.innerText || '').slice(0, 400)));
    out.push('  questionLi 里的 qtContent: ' + JSON.stringify((el.querySelector('.qtContent') ? el.querySelector('.qtContent').innerText : '(无)').slice(0, 120)));
  });

  // 我的答案为空的情况
  const noMy = qs.filter(function (q) { return !q.myAnswer; });
  out.push('\n我的答案为空=' + noMy.length);
  noMy.slice(0, 5).forEach(function (q, i) {
    out.push('  [' + i + '] stem=' + JSON.stringify(q.stem.slice(0, 50)) + ' ans=' + JSON.stringify(q.answer));
  });
  return out.join('\n');
})();
