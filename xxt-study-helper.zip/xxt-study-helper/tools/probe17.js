(function () {
  const out = [];
  const base = '/exam-ans/exam/test/reVersionPaperMarkContentNew?courseId=255245407&classId=128925575&p=1&id=169550368&ut=s&openc=807f581a17de304191ec9136c3fd1f64&newMooc=true';
  const variants = [
    ['times=1', base + '&times=1'],
    ['times=1&showAnswer=1', base + '&times=1&showAnswer=1'],
    ['times=1&isTeacher=true', base + '&times=1&isTeacher=true'],
    ['times=1&showAnswerRight=1', base + '&times=1&showAnswerRight=1'],
    ['times=1&type=1', base + '&times=1&type=1'],
    ['times=0', base + '&times=0']
  ];
  let k = 0;
  let done;
  const p = new Promise(function (r) { done = r; });
  function next() {
    if (k >= variants.length) { done(out.join('\n')); return; }
    const v = variants[k++];
    jQuery.ajax({
      type: 'get', url: v[1], dataType: 'html', timeout: 15000,
      success: function (data) {
        const s = String(data).replace(/<!--[\s\S]*?-->/g, '');
        out.push(v[0] + ' len=' + s.length +
          ' | rightAnswerContent=' + (s.split('rightAnswerContent').length - 1) +
          ' | qtAnalysis=' + (s.split('qtAnalysis').length - 1) +
          ' | mark_key=' + (s.split('mark_key').length - 1) +
          ' | 正确答案=' + (s.split('正确答案').length - 1));
        next();
      },
      error: function (xhr, st) { out.push(v[0] + ' ERR ' + st); next(); }
    });
  }
  next();
  return p;
})();
