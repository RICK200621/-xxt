(function () {
  const out = [];
  const el = document.querySelector('.questionLi');
  const li = el.querySelectorAll('ul li');
  out.push('ul li = ' + li.length);
  li.forEach(function (x, i) {
    const cs = getComputedStyle(x);
    const r = x.getBoundingClientRect();
    out.push('  li[' + i + '] display=' + cs.display + ' vis=' + cs.visibility + ' op=' + cs.opacity +
      ' rect=' + Math.round(r.width) + 'x' + Math.round(r.height) + ' text=' + JSON.stringify(x.innerText));
  });
  // guan 键：extract.js 里 findOptionWraps 用 isVisible，isVisible 检查 position fixed + transform
  li.forEach(function (x, i) {
    const cs = getComputedStyle(x);
    out.push('  li[' + i + '] position=' + cs.position + ' transform=' + cs.transform);
  });
  // ul 的样式
  const ul = el.querySelector('ul');
  const csu = getComputedStyle(ul);
  out.push('ul display=' + csu.display + ' visibility=' + csu.visibility + ' opacity=' + csu.opacity + ' rect=' + JSON.stringify((function (r) { return [r.width, r.height]; })(ul.getBoundingClientRect())));
  return out.join('\n');
})();
