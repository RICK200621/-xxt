(function () {
  const out = [];
  out.push('---- 所有含 答案/解析 文本的元素的 class/tag ----');
  const seen = new Set();
  document.querySelectorAll('*').forEach((el) => {
    const t = (el.innerText || '').trim();
    if (!t || t.length > 200) return;
    if (!/^(查看|展开|显示)?(参考|正确)?(答案|解析)|解析$|查看答案/.test(t)) return;
    const key = el.tagName + '|' + (el.className || '');
    if (seen.has(key)) return;
    seen.add(key);
    out.push(key + ' | text=' + JSON.stringify(t.slice(0, 60)) + ' | onclick=' + (el.getAttribute('onclick') || '').slice(0, 80));
  });
  out.push('---- 页面顶部控件 ----');
  [...document.querySelectorAll('a,button,div.btn,span.btn')].slice(0, 60).forEach((e) => {
    const t = (e.innerText || '').trim().replace(/\s+/g, ' ');
    if (!t || t.length > 20) return;
    out.push(e.tagName + ' | ' + (typeof e.className === 'string' ? e.className : '') + ' | ' + JSON.stringify(t));
  });
  out.push('---- 是否有 智能分析 / 最终成绩 链接 ----');
  [...document.querySelectorAll('a')].forEach((a) => {
    if (/智能分析|成绩|答案|解析/.test(a.innerText || '')) out.push(JSON.stringify(a.innerText.trim()) + ' -> ' + a.href);
  });
  return out.join('\n');
})();
