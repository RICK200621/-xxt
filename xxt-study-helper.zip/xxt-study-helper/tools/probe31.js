(function () {
  const out = [];
  out.push('xxtHelper=' + typeof window.xxtHelper);
  if (!window.xxtHelper || !window.xxtHelper.extractFrom) return out.join('\n');
  const t0 = Date.now();
  let qs;
  try {
    qs = window.xxtHelper.extractFrom(document.body);
  } catch (e) {
    return '异常: ' + e + '\n' + (e.stack || '');
  }
  out.push('耗时=' + (Date.now() - t0) + 'ms, 题数=' + qs.length);
  qs.slice(0, 5).forEach(function (q, i) {
    out.push('--- 题' + (i + 1) + ' [' + q.type + '] rawId=' + q.rawId + ' ---');
    out.push('  题干: ' + JSON.stringify(q.stem.slice(0, 90)));
    out.push('  选项: ' + q.options.map(function (o) { return o.key + '.' + o.text; }).join(' | '));
    out.push('  我的答案: ' + JSON.stringify(q.myAnswer) + ' | 正确答案: ' + JSON.stringify(q.answer) + ' | 判定: ' + (window.xxtHelper.judge(q.myAnswer, q.answer, q.type)));
    out.push('  解析: ' + JSON.stringify((q.analysis || '').slice(0, 120)));
  });
  const cnt = { options0: 0, noMy: 0, noAns: 0, noAnalysis: 0, dirty: 0 };
  qs.forEach(function (q) {
    if (!q.options.length) cnt.options0++;
    if (!q.myAnswer) cnt.noMy++;
    if (!q.answer) cnt.noAns++;
    if (!q.analysis) cnt.noAnalysis++;
    if (/;|：;|^:/.test(q.answer || '')) cnt.dirty++;
  });
  out.push('统计: ' + JSON.stringify(cnt));
  const types = {};
  qs.forEach(function (q) { types[q.type] = (types[q.type] || 0) + 1; });
  out.push('题型: ' + JSON.stringify(types));
  return out.join('\n');
})();
