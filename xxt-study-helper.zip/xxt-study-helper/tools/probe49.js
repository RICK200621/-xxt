(function () {
  const out = [];
  const NS = window.xxtHelper;

  // 构造干净容器
  const box = document.createElement('div');
  document.body.appendChild(box);
  const blocks = [...document.querySelectorAll('.questionLi')].map(function (el) { return el.cloneNode(true); });
  blocks.forEach(function (b) { box.appendChild(b); });

  // 手动跑 parseContainer 等价流程：用 extractFrom 拿不到内部，
  // 那就用 extractFrom(box) 后交叉比对 rawId
  const r = NS.extractFrom(box);
  const gotIds = new Set(r.map(function (q) { return String(q.rawId); }));
  const lost = [];
  blocks.forEach(function (b) {
    const id = b.getAttribute('data');
    if (!gotIds.has(String(id))) lost.push(id);
  });
  out.push('容器内块数=' + blocks.length + ' 抽出=' + r.length);
  out.push('丢失 id: ' + lost.join(','));
  out.push('_lastDropped=' + JSON.stringify(NS._lastDropped || []));
  out.push('_lastFinalDropped=' + JSON.stringify(NS._lastFinalDropped || []));

  // 逐个把丢失的块放进容器单独抽
  out.push('\n---- 单独抽丢失块 ----');
  lost.forEach(function (id) {
    const b = blocks.find(function (x) { return x.getAttribute('data') === id; });
    if (!b) return;
    const w = document.createElement('div');
    document.body.appendChild(w);
    w.appendChild(b.cloneNode(true));
    const g = NS.extractFrom(w);
    out.push(id + ' => ' + g.length + ' 题' + (g[0] ? ' stem=' + JSON.stringify(g[0].stem.slice(0, 30)) + ' opts=' + g[0].options.length + ' my=' + JSON.stringify(g[0].myAnswer) + ' ans=' + JSON.stringify(g[0].answer) : ''));
    w.remove();
  });
  box.remove();
  return out.join('\n');
})();
