(async function () {
  const out = [];
  const base = location.origin + '/';
  const files = ['src/common.js', 'src/extract.js'];
  for (const f of files) {
    const r = await fetch(base + f);
    const code = await r.text();
    const s = document.createElement('script');
    s.textContent = code;
    document.documentElement.appendChild(s);
  }
  out.push('注入后 xxtHelper=' + typeof window.xxtHelper);
  if (!window.xxtHelper) return out.join('\n');
  try {
    const qs = window.xxtHelper.extractFrom(document.body);
    out.push('extractFrom 题数=' + qs.length);
    qs.slice(0, 3).forEach(function (q, i) {
      out.push('题' + (i + 1) + ': stem=' + JSON.stringify(q.stem.slice(0, 60)) +
        ' | opts=' + q.options.length +
        ' | my=' + JSON.stringify(q.myAnswer) + ' | ans=' + JSON.stringify(q.answer) +
        ' | type=' + q.type + ' | analysis=' + JSON.stringify((q.analysis || '').slice(0, 40)));
    });
  } catch (e) {
    out.push('异常: ' + e + '\n' + (e.stack || ''));
  }
  return out.join('\n');
})();
