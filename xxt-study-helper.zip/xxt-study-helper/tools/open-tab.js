const http = require('http');

function put(url) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const req = http.request({
      hostname: u.hostname, port: u.port, path: u.pathname + u.search, method: 'PUT'
    }, (res) => {
      let d = '';
      res.on('data', (c) => (d += c));
      res.on('end', () => resolve(d));
    });
    req.on('error', reject);
    req.end();
  });
}
function get(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let d = '';
      res.on('data', (c) => (d += c));
      res.on('end', () => resolve(d));
    }).on('error', reject);
  });
}

const url = 'https://stat2-ans.chaoxing.com/study-knowledge/ans?courseid=255245407&cpi=415894527&clazzid=128925575&ut=s&relationId=7877691&type=4';

(async () => {
  const enc = encodeURIComponent(url);
  const r = await put('http://127.0.0.1:9222/json/new?' + enc);
  console.log('new tab ->', r.slice(0, 200));
  await new Promise((r2) => setTimeout(r2, 6000));
  const list = JSON.parse(await get('http://127.0.0.1:9222/json/list'));
  const t = list.find((p) => p.type === 'page' && /stat2-ans/.test(p.url));
  if (!t) { console.log('未找到 stat2-ans 标签页'); list.forEach((p) => console.log(' ', p.title, p.url.slice(0, 100))); return; }
  console.log('tab:', t.title, t.id);
  require('fs').writeFileSync(require('path').join(__dirname, '_stat2.json'), JSON.stringify({ ws: t.webSocketDebuggerUrl, id: t.id, title: t.title, url: t.url }, null, 1));
  console.log('saved');
})();
