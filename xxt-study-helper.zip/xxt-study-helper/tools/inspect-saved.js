// 读取用户 Ctrl+S 保存的页面 HTML，统计关键选择器命中，并跑一次真实抽取
const fs = require('fs');
const path = require('path');

const file = process.argv[2];
if (!file) {
  console.log('用法: node tools/inspect-saved.js <保存的.html>');
  process.exit(1);
}
const html = fs.readFileSync(file, 'utf8');
console.log('文件:', file);
console.log('字节:', Buffer.byteLength(html), ' 字符:', html.length);
console.log('title:', (html.match(/<title>([\s\S]*?)<\/title>/) || [])[1]);

const patterns = [
  ['questionLi', /class="[^"]*\bquestionLi\b/g],
  ['singleQuesId', /singleQuesId/g],
  ['mark_name', /class="[^"]*\bmark_name\b/g],
  ['mark_letter', /class="[^"]*\bmark_letter\b/g],
  ['mark_answer', /class="[^"]*\bmark_answer\b/g],
  ['stuAnswerContent', /stuAnswerContent/g],
  ['rightAnswerContent', /rightAnswerContent/g],
  ['qtAnalysis', /qtAnalysis/g],
  ['analysis', /class="[^"]*\banalysis\b/g],
  ['element-invisible-hidden', /element-invisible-hidden/g],
  ['TiMu', /class="[^"]*\bTiMu\b/g],
  ['mark_item', /class="[^"]*\bmark_item\b/g],
  ['iframe', /<iframe/gi],
  ['正确答案', /正确答案/g],
  ['参考答案', /参考答案/g],
  ['我的答案', /我的答案/g],
  ['你的答案', /你的答案/g],
  ['解析', /解析/g],
  ['AI讲解', /AI讲解/g],
  ['script标签', /<script/gi]
];
console.log('\n=== 关键词计数 ===');
for (const [k, re] of patterns) {
  const n = (html.match(re) || []).length;
  console.log('  ' + k.padEnd(26) + n);
}

// 跑一次 jsdom 抽取
const { JSDOM } = require('jsdom');
const dom = new JSDOM(html, {
  url: 'https://mooc1.chaoxing.com/exam-ans/exam/test/reVersionPaperMarkContentNew',
  pretendToBeVisual: true,
  runScripts: 'outside-only'
});
const { window } = dom;

// jsdom 适配：innerText / 可见性 / chrome storage
Object.defineProperty(window.HTMLElement.prototype, 'innerText', {
  get() {
    return this.textContent;
  },
  set(v) {
    this.textContent = v;
  },
  configurable: true
});
const sizeRect = { width: 100, height: 20, top: 0, left: 0, right: 100, bottom: 20, x: 0, y: 0, toJSON() {} };
window.Element.prototype.getBoundingClientRect = function () {
  return Object.assign({}, sizeRect);
};
window.chrome = { storage: { local: { get: (k, cb) => cb({}), set: (o, cb) => cb && cb() } } };

const PROJ = path.resolve(__dirname, '..');
for (const f of ['src/common.js', 'src/extract.js']) {
  const code = fs.readFileSync(path.join(PROJ, f), 'utf8');
  window.eval(code);
}
const NS = window.xxtHelper;
console.log('\n=== 脚本状态 ===');
console.log('  VERSION:', NS.VERSION, ' extract?', typeof NS.extractFrom);
if (NS.diagnose) {
  console.log('  diagnose:', JSON.stringify(NS.diagnose(window.document.body), null, 2));
}

const t0 = Date.now();
const qs = NS.extractFrom(window.document.body);
console.log('\n=== 抽取结果 ===');
console.log('  题数:', qs.length, ' 耗时:', Date.now() - t0, 'ms');
if (qs.length) {
  const stat = {
    options0: qs.filter((q) => !q.options || !q.options.length).length,
    noMy: qs.filter((q) => !q.myAnswer).length,
    noAns: qs.filter((q) => !q.answer).length,
    noAnalysis: qs.filter((q) => !q.analysis).length
  };
  console.log('  统计:', JSON.stringify(stat));
  const byType = {};
  qs.forEach((q) => (byType[q.type] = (byType[q.type] || 0) + 1));
  console.log('  题型:', JSON.stringify(byType));
  console.log('  每 20 题取一个样例：');
  qs.forEach((q, i) => {
    if (i % 20 !== 0 && i !== qs.length - 1) return;
    console.log('   #' + (i + 1) + ' type=' + q.type + ' rawId=' + q.rawId);
    console.log('     stem:', (q.stem || '').slice(0, 90));
    console.log('     opts:', (q.options || []).map((o) => o.key + '.' + o.text.slice(0, 16)).join(' | '));
    console.log('     my=' + JSON.stringify(q.myAnswer) + ' ans=' + JSON.stringify(q.answer) + ' correct=' + q.correct);
    console.log('     analysis:', (q.analysis || '(空)').slice(0, 80));
  });
} else {
  console.log('  ⚠️ 一题都没抽到');
  // 排查：选择器逐个统计
  const CONTAINER_SELS = [
    '.questionLi', '.question-item', '.questionItem', '.mark_item', '.TiMu', '.AiTiMu',
    '[data-questionid]', '[data-question-id]', '.subject', '.queBox', '.question',
    '.topic-item', '.ti-item', '.singleQuesId'
  ];
  console.log('\n=== 选择器命中（不过滤可见性）===');
  for (const s of CONTAINER_SELS) {
    let n = 0;
    try {
      n = window.document.body.querySelectorAll(s).length;
    } catch (e) {
      n = -1;
    }
    if (n) console.log('  ' + s.padEnd(22) + n);
  }
  const bodyText = (window.document.body.textContent || '').replace(/\s+/g, ' ').trim();
  console.log('\n正文纯文本长度:', bodyText.length);
  console.log('正文前 600 字:', bodyText.slice(0, 600));
}
