(function () {
  const out = [];
  out.push('==== 页面上能看到的按钮/链接文本 ====');
  const btns = [];
  document.querySelectorAll('a,button,span,i,div').forEach(function (el) {
    const t = (el.innerText || '').trim();
    if (!t || t.length > 12) return;
    if (/分析|详情|解析|答案|错题|重做|记录|试卷/.test(t)) {
      const oc = el.getAttribute('onclick') || '';
      const href = el.getAttribute('href') || '';
      if (btns.length < 60) btns.push(t + ' | onclick=' + oc.slice(0, 120) + ' | href=' + href.slice(0, 120));
    }
  });
  out.push(btns.join('\n'));
  out.push('==== 智能分析 元素的 onclick 与 URL ====');
  const a = [...document.querySelectorAll('a')].find(function (x) { return (x.innerText || '').trim() === '智能分析'; });
  if (a) out.push('outerHTML: ' + a.outerHTML + '\nparent: ' + (a.parentElement && a.parentElement.outerHTML.slice(0, 600)));
  return out.join('\n');
})();
