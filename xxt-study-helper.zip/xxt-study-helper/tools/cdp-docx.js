const http = require('http');
const fs = require('fs');
const path = require('path');

function getJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let d = '';
      res.on('data', (c) => (d += c));
      res.on('end', () => resolve(JSON.parse(d)));
    }).on('error', reject);
  });
}

class CDP {
  constructor(wsUrl) { this.ws = new WebSocket(wsUrl); this.id = 0; this.pending = new Map(); }
  async open() {
    await new Promise((res, rej) => { this.ws.onopen = res; this.ws.onerror = rej; });
    this.ws.onmessage = (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) reject(new Error(JSON.stringify(msg.error)));
        else resolve(msg.result);
      }
    };
    return this;
  }
  send(method, params) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params: params || {} }));
    });
  }
  async eval(expr, awaitPromise) {
    const r = await this.send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: !!awaitPromise });
    if (r.exceptionDetails) throw new Error('页面异常: ' + JSON.stringify(r.exceptionDetails.exception || r.exceptionDetails));
    return r.result.value;
  }
  close() { this.ws.close(); }
}

const PROJ = path.join(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 用法: node tools/cdp-docx.js <输出docx相对路径>
(async () => {
  const outFile = process.argv[2] || 'build/_live.docx';

  const list = await getJson('http://127.0.0.1:9222/json/list');
  const pages = list.filter((p) => p.type === 'page' && /chaoxing/.test(p.url));
  // 优先选真正带题目的页面：作业详情(work/view) 答案最全，其次试卷回顾页
  const paper =
    pages.find((p) => /mooc2\/work\/view/.test(p.url)) ||
    pages.find((p) => /reVersionPaper|MarkContent/.test(p.url));
  if (!paper) {
    console.log('没找到带题目的页面（需要 mooc2/work/view 或 reVersionPaper），当前标签页:');
    pages.forEach((p) => console.log('  ', p.title, '|', p.url.slice(0, 120)));
    process.exit(1);
  }
  const t = paper;
  console.log('标签页:', t.title);

  const cdp = await new CDP(t.webSocketDebuggerUrl).open();
  await cdp.send('Page.enable');
  await cdp.send('Page.reload', { ignoreCache: true });
  await sleep(6000);
  await cdp.eval('try{delete window.xxtHelper}catch(e){};1', false);

  for (const f of ['src/common.js', 'src/extract.js', 'src/docxgen.js', 'build/docx.bundle.js']) {
    const code = fs.readFileSync(path.join(PROJ, f), 'utf8');
    await cdp.eval(code, false);
    console.log('已注入:', f);
  }
  console.log('docx 导出数:', await cdp.eval('Object.keys(window.docx||{}).length', false));
  console.log('docxgen 就绪:', await cdp.eval('typeof (window.xxtHelper&&window.xxtHelper.buildDocx)', false));

  const code = fs.readFileSync(path.join(PROJ, 'tools', 'probe27.js'), 'utf8');
  const res = await cdp.eval(code, true);
  if (typeof res !== 'string' || res.indexOf('DOCX_BASE64:') !== 0) {
    console.log('生成失败:', res);
    cdp.close();
    process.exit(1);
  }
  const buf = Buffer.from(res.slice('DOCX_BASE64:'.length), 'base64');
  const target = path.join(PROJ, outFile);
  fs.writeFileSync(target, buf);
  console.log('已保存:', target, buf.length, 'bytes');
  cdp.close();
})().catch((e) => { console.error(e); process.exit(1); });
