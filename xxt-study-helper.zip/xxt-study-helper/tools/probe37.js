(function () {
  const out = [];
  const NS = window.xxtHelper;

  // 检查注入的 extract.js 是不是新版（找 optKey 关键字）
  const src = String(NS.extractFrom);
  out.push('extractFrom 源码里含 optKey 吗: ' + /optKey/.test(src));

  // 对照 38 和 8 两题的完整数据
  const el8 = document.getElementById('question214104358');
  const el38 = document.getElementById('question214104388');
  function info(el) {
    if (!el) return null;
    const lis = [...el.querySelectorAll('.mark_letter li')];
    const w = document.createElement('div');
    w.appendChild(el.cloneNode(true));
    document.body.appendChild(w);
    const q = NS.extractFrom(w)[0];
    w.remove();
    return q;
  }
  const q8 = info(el8), q38 = info(el38);
  [['#8', q8], ['#38', q38]].forEach(function (p) {
    const q = p[1];
    if (!q) { out.push(p[0] + ' = null'); return; }
    out.push(p[0] + ' stem=' + JSON.stringify(q.stem));
    out.push('   opts=' + JSON.stringify(q.options));
    out.push('   my=' + JSON.stringify(q.myAnswer) + ' ans=' + JSON.stringify(q.answer));
    const optKey = (q.options || []).map(function (o) { return o.key + o.text; }).join('|');
    out.push('   去重键=' + JSON.stringify(q.stem.slice(0, 80) + '#' + q.answer + '#' + q.myAnswer + '#' + optKey));
  });
  return out.join('\n');
})();
