(function () {
  const out = [];
  out.push('xxtHelper=' + typeof window.xxtHelper);
  if (!window.xxtHelper || !window.xxtHelper.extractFrom) return out.join('\n');
  try {
    const qs = window.xxtHelper.extractFrom(document.body);
    out.push('extractFrom 题数=' + qs.length);
    qs.slice(0, 4).forEach(function (q, i) {
      out.push('题' + (i + 1) + ': stem=' + JSON.stringify(q.stem.slice(0, 70)));
      out.push('      opts=' + JSON.stringify(q.options) + ' | my=' + JSON.stringify(q.myAnswer) +
        ' | ans=' + JSON.stringify(q.answer) + ' | type=' + q.type);
    });
    // 分布统计
    const cnt = { options0: 0, noMy: 0, noAns: 0, noAnalysis: 0 };
    qs.forEach(function (q) {
      if (!q.options.length) cnt.options0++;
      if (!q.myAnswer) cnt.noMy++;
      if (!q.answer) cnt.noAns++;
      if (!q.analysis) cnt.noAnalysis++;
    });
    out.push('统计: ' + JSON.stringify(cnt) + ' / 总题数=' + qs.length);
  } catch (e) {
    out.push('异常: ' + e + '\n' + (e.stack || ''));
  }
  return out.join('\n');
})();
