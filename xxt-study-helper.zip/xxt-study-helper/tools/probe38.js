(function () {
  const out = [];
  const el = document.getElementById('question214104388');

  // 看 extractFrom 的完整源码，找筛选逻辑
  const src = String(window.xxtHelper.extractFrom);
  out.push('==== extractFrom 源码（前 3000 字）====');
  out.push(src.slice(0, 3000));
  return out.join('\n');
})();
