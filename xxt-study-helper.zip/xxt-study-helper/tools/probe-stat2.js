(function () {
  const out = [];
  out.push('URL: ' + location.href);
  out.push('title: ' + document.title);
  out.push('body 长度: ' + (document.body ? document.body.innerText.length : -1));
  out.push('---- body 前 3000 字 ----');
  out.push((document.body ? document.body.innerText : '').slice(0, 3000));
  out.push('---- 是否含关键词 ----');
  ['正确答案', '解析', 'rightAnswer', 'answer'].forEach(function (k) {
    out.push(k + ' : ' + (document.documentElement.innerHTML.split(k).length - 1));
  });
  return out.join('\n');
})();
