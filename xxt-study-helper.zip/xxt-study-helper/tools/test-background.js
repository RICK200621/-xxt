// 用 mock chrome 跑 background.js，确认 xxt-download 真的把 dataUrl 交给 downloads.download
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const PROJ = path.join(__dirname, '..');
const src = fs.readFileSync(path.join(PROJ, 'background.js'), 'utf8');

const calls = { download: [], executeScript: [], sendMessage: [] };
let listener = null;

const chrome = {
  runtime: {
    onMessage: { addListener: (fn) => { listener = fn; } },
    onInstalled: { addListener: () => {} },
    onStartup: { addListener: () => {} },
    getURL: (p) => 'chrome-extension://fake/' + p,
    lastError: null
  },
  tabs: {
    sendMessage: (tabId, msg, cb) => { calls.sendMessage.push({ tabId, type: msg && msg.type }); cb(undefined); },
    query: (q, cb) => cb([])
  },
  scripting: {
    executeScript: (opts, cb) => { calls.executeScript.push(opts); cb([{ result: true }]); }
  },
  action: {
    onClicked: { addListener: () => {} },
    setBadgeText: () => {},
    setBadgeBackgroundColor: () => {}
  },
  commands: { onCommand: { addListener: () => {} } },
  contextMenus: { create: () => {}, onClicked: { addListener: () => {} }, removeAll: (cb) => cb && cb() },
  downloads: {
    download: (opts, cb) => { calls.download.push(opts); cb && cb(1); },
    onChanged: { addListener: () => {} }
  },
  storage: { local: { get: (k, cb) => cb({}), set: (o, cb) => cb && cb() } }
};

const sandbox = { chrome, console, setTimeout, clearTimeout, URL, fetch: () => Promise.reject(new Error('no net')) };
sandbox.self = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
vm.runInContext(src, sandbox, { filename: 'background.js' });

console.log('装了 onMessage 监听:', typeof listener === 'function');

// 造一个真 docx 的 data URL（用 build 里现成的文件）
const docxPath = path.join(PROJ, 'build', '_e2e-download.docx');
const b64 = fs.readFileSync(docxPath).toString('base64');
const dataUrl = 'data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,' + b64;
console.log('测试用 dataUrl 长度:', dataUrl.length);

const resp = listener({ type: 'xxt-download', dataUrl, filename: '测试-复习题.docx' }, { id: 'fake' }, (r) => {
  console.log('sendResponse:', JSON.stringify(r));
  return true;
});

setTimeout(() => {
  console.log('downloads.download 调用次数:', calls.download.length);
  if (calls.download.length) {
    const o = calls.download[0];
    console.log('  url 前缀:', String(o.url).slice(0, 60));
    console.log('  url 长度:', String(o.url).length);
    console.log('  filename:', o.filename);
    console.log('  saveAs:', o.saveAs);
    // 再把传进去的 URL 解码回文件，确认没被破坏
    const back = Buffer.from(String(o.url).split(',')[1], 'base64');
    const ok = back.length === fs.statSync(docxPath).size && back.slice(0, 2).toString() === 'PK';
    console.log('  解码后字节:', back.length, 'zip 头正确:', ok);
  } else {
    console.log('!! 没有调用 downloads.download');
  }
}, 500);
