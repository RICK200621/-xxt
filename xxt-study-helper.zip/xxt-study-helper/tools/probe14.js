(function () {
  const out = [];
  const targets = [
    ['智能分析-stat2ans', 'https://stat2-ans.chaoxing.com/study-knowledge/ans?courseid=255245407&cpi=415894527&clazzid=128925575&ut=s&relationId=7877691&type=4'],
    ['试卷详情look', 'https://mooc1.chaoxing.com/exam-ans/exam/test/look?courseId=255245407&classId=128925575&examId=7877691&examAnswerId=169550368&cpi=415894527'],
    ['reVersionPaper-noTimes', 'https://mooc1.chaoxing.com/exam-ans/exam/test/reVersionPaperMarkContentNew?courseId=255245407&classId=128925575&p=1&id=169550368&ut=s&openc=807f581a17de304191ec9136c3fd1f64&newMooc=true']
  ];
  let k = 0;
  function next() {
    if (k >= targets.length) return resolve2();
    const it = targets[k++];
    out.push('==== ' + it[0] + ' ====');
    jQuery.ajax({
      type: 'get', url: it[1], dataType: 'html', timeout: 15000,
      success: function (data) {
        const s = String(data);
        out.push('len=' + s.length);
        const nc = s.replace(/<!--[\s\S]*?-->/g, '');
        ['rightAnswerContent', 'qtAnalysis', '正确答案', 'mark_letter', 'questionLi', 'questype'].forEach(function (key) {
          out.push('  ' + key + ' : ' + (nc.split(key).length - 1));
        });
        next();
      },
      error: function (xhr, st) { out.push('ERR ' + st + ' ' + (xhr && xhr.status)); next(); }
    });
  }
  let resolve2;
  return new Promise(function (resolve) {
    resolve2 = function () { resolve(out.join('\n')); };
    next();
  });
})();
