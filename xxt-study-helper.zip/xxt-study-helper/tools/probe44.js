(function () {
  const out = [];
  const NS = window.xxtHelper;
  const qs = NS.extractFrom(document.body);
  out.push('抽出=' + qs.length);
  out.push('==== 被 parseContainer 丢掉的块 ====');
  const d = NS._lastDropped || [];
  out.push('数量=' + d.length);
  d.slice(0, 20).forEach(function (x) { out.push('  ' + x); });
  return out.join('\n');
})();
