(function () {
  const out = [];
  out.push('---- 页面顶部按钮/链接全量 ----');
  [...document.querySelectorAll('a,button,span,i,div')].forEach((e) => {
    const t = (e.innerText || '').trim();
    if (!t || t.length > 12) return;
    if (!/答案|解析|查看|展开|显示|还原/.test(t)) return;
    const cls = typeof e.className === 'string' ? e.className : '';
    out.push(e.tagName + ' | class=' + cls + ' | text=' + JSON.stringify(t) + ' | onclick=' + (e.getAttribute('onclick') || '').slice(0, 100));
  });
  out.push('---- 全局函数名 ----');
  out.push(Object.keys(window).filter((k) => /answer|Answer|解析|show/i.test(k)).join(', '));
  out.push('---- 是否有答案接口 ----');
  const srcs = [...document.querySelectorAll('script[src]')].map((s) => s.src);
  out.push(srcs.filter((s) => /exam|answer/i.test(s)).join('\n'));
  return out.join('\n');
})();
