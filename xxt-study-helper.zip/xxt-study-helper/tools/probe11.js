(function () {
  const out = [];
  const url = '/exam-ans/exam/test/reVersionPaperMarkContentNew?courseId=255245407&classId=128925575&p=1&id=169550368&ut=s&openc=807f581a17de304191ec9136c3fd1f64&times=1&newMooc=true';
  return new Promise(function (resolve) {
    const t = setTimeout(function () {
      out.push('TIMEOUT');
      resolve(out.join('\n'));
    }, 20000);
    jQuery.ajax({
      type: 'get',
      url: url,
      dataType: 'html',
      success: function (data) {
        clearTimeout(t);
        const s = String(data);
        out.push('OK len=' + s.length);
        out.push('含正确答案:' + /正确答案/.test(s) + ' 含解析:' + /解析/.test(s) + ' questionLi:' + (s.match(/questionLi/g) || []).length);
        const i = s.indexOf('mark_answer');
        out.push('---- mark_answer 附近 ----');
        out.push(s.slice(Math.max(0, i - 200), i + 2500));
        resolve(out.join('\n'));
      },
      error: function (xhr, st, e) {
        clearTimeout(t);
        out.push('ERR ' + st + ' status=' + (xhr && xhr.status));
        resolve(out.join('\n'));
      }
    });
  });
})();
