(function () {
  const out = [];
  const el = document.getElementById('question214104388');
  if (!el) return '找不到块';

  // 手动复刻 parseContainer 全流程
  const clean = function (s) {
    if (s == null) return '';
    return String(s).replace(/[\u200b-\u200f\u202a-\u202e\ufeff]/g, '').replace(/[\u00a0\u3000]/g, ' ')
      .replace(/[ \t]+/g, ' ').replace(/\s*\n\s*/g, '\n').trim();
  };
  const oneLine = function (s) { return clean(s).replace(/\n+/g, ' '); };

  // 模拟 isVisible
  function isVisible(x) {
    if (!x || !x.isConnected) return false;
    const st = getComputedStyle(x);
    if (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
    if (st.position === 'fixed' && /translate\(-?[1-9]\d{2,}px/.test(st.transform || '')) return false;
    const r = x.getBoundingClientRect();
    return r.width > 0 || r.height > 0;
  }

  out.push('isVisible(el)=' + isVisible(el));

  // 选项
  const lis = [...el.querySelectorAll('.mark_letter li')];
  out.push('li 数=' + lis.length + ' 全部可见=' + lis.every(isVisible));

  // 题干
  const stemEl = el.querySelector('.mark_name');
  out.push('题干 raw=' + JSON.stringify(oneLine(stemEl.textContent)));

  // ANSWER 读取
  const st = el.querySelector('.stuAnswerContent');
  const ra = el.querySelector('.rightAnswerContent');
  out.push('我的答案 raw=' + JSON.stringify(st ? st.textContent : '(无)'));
  out.push('正确答案 raw=' + JSON.stringify(ra ? ra.textContent : '(无)'));

  // 关键检查：这个块是否在某个 CONTAINER_SEL 命中集合里被 contains 过滤掉
  const checked = [...document.querySelectorAll('.questionLi')];
  const outer = checked.filter(function (o) { return o !== el && o.contains(el); });
  out.push('包含该块的其它 .questionLi 数=' + outer.length);
  outer.forEach(function (o) { out.push('  外层: ' + o.id + ' class=' + o.className); });

  // 这个块本身有没有被 contains 反向包含
  const inner = checked.filter(function (o) { return o !== el && el.contains(o); });
  out.push('被该块包含的其它 .questionLi 数=' + inner.length);
  return out.join('\n');
})();
