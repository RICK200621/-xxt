(function () {
  const out = [];
  const sels = ['.questionLi', '.mark_name', '.mark_letter', '.mark_answer'];
  sels.forEach(function (s) {
    const els = [...document.querySelectorAll(s)];
    out.push(s + ' 总数=' + els.length);
    els.slice(0, 3).forEach(function (el, i) {
      const cs = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      out.push('  [' + i + '] display=' + cs.display + ' visibility=' + cs.visibility + ' opacity=' + cs.opacity +
        ' rect=' + Math.round(r.width) + 'x' + Math.round(r.height) + ' connected=' + el.isConnected);
    });
  });
  // 模拟 extract.js 的 isVisible
  const probe = document.createElement('div');
  probe.style.cssText = 'position:absolute;left:-9999px;top:0;width:10px;height:10px';
  document.body.appendChild(probe);
  out.push('nativeLayout=' + (probe.getBoundingClientRect().width > 0));
  probe.remove();

  // 看看 mark_name 的文本
  const mn = document.querySelector('.mark_name');
  out.push('mark_name innerText=' + JSON.stringify(mn ? mn.innerText : null));

  // 检查抽取脚本是否已注入
  out.push('xxtHelper存在=' + (typeof window.xxtHelper));
  if (window.xxtHelper && window.xxtHelper.extractFrom) {
    try {
      const qs = window.xxtHelper.extractFrom(document.body);
      out.push('extractFrom 返回题数=' + qs.length);
      qs.slice(0, 2).forEach(function (q, i) {
        out.push('  题' + (i + 1) + ' stem=' + JSON.stringify((q.stem || '').slice(0, 80)) +
          ' opts=' + q.options.length + ' my=' + q.myAnswer + ' ans=' + q.answer + ' type=' + q.type);
      });
    } catch (e) {
      out.push('extractFrom 异常: ' + e);
    }
  }
  return out.join('\n');
})();
