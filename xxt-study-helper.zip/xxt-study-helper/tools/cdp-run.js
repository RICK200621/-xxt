// 通过 CDP 在页面里执行 JS，读取试卷真实 DOM 结构
const http = require('http');

function getJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let d = '';
      res.on('data', (c) => (d += c));
      res.on('end', () => resolve(JSON.parse(d)));
    }).on('error', reject);
  });
}

class CDP {
  constructor(wsUrl) {
    this.ws = new WebSocket(wsUrl);
    this.id = 0;
    this.pending = new Map();
  }
  async open() {
    await new Promise((res, rej) => {
      this.ws.onopen = res;
      this.ws.onerror = rej;
    });
    this.ws.onmessage = (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) reject(new Error(JSON.stringify(msg.error)));
        else resolve(msg.result);
      }
    };
    return this;
  }
  send(method, params) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params: params || {} }));
    });
  }
  async eval(expr, awaitPromise) {
    const r = await this.send('Runtime.evaluate', {
      expression: expr,
      returnByValue: true,
      awaitPromise: !!awaitPromise,
      userGesture: true
    });
    if (r.exceptionDetails) {
      throw new Error('页面异常: ' + JSON.stringify(r.exceptionDetails.exception || r.exceptionDetails));
    }
    return r.result.value;
  }
  close() { this.ws.close(); }
}

async function main() {
  const list = await getJson('http://127.0.0.1:9222/json/list');
  const pages = list.filter((p) => p.type === 'page');
  const target = pages.find((p) => /exam-ans|exam\/test|reVersionPaper/.test(p.url)) || pages.find((p) => /chaoxing/.test(p.url));
  if (!target) {
    console.log('没找到试卷页');
    pages.forEach((p) => console.log(' ', p.title, p.url));
    process.exit(1);
  }
  console.log('目标页:', target.title, target.url.slice(0, 120));
  const cdp = await new CDP(target.webSocketDebuggerUrl).open();
  const code = require('fs').readFileSync(process.argv[2], 'utf8');
  const out = await cdp.eval(code, true);
  console.log(typeof out === 'string' ? out : JSON.stringify(out, null, 2));
  cdp.close();
}

main().catch((e) => { console.error(e); process.exit(1); });
