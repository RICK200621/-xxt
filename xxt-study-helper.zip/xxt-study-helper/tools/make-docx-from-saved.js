// 从用户 Ctrl+S 保存的页面 HTML 离线生成 Word（不依赖浏览器扩展）
// 用法: node tools/make-docx-from-saved.js <保存的.html> <输出.docx> [标题]
const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

const src = process.argv[2];
const out = process.argv[3];
let title = process.argv[4] || '';

const html = fs.readFileSync(src, 'utf8');
const dom = new JSDOM(html, {
  url: 'https://mooc1.chaoxing.com/exam-ans/exam/test/reVersionPaperMarkContentNew',
  pretendToBeVisual: true,
  runScripts: 'outside-only'
});
const { window } = dom;

Object.defineProperty(window.HTMLElement.prototype, 'innerText', {
  get() { return this.textContent; },
  set(v) { this.textContent = v; },
  configurable: true
});
const sizeRect = { width: 100, height: 20, top: 0, left: 0, right: 100, bottom: 20, x: 0, y: 0, toJSON() {} };
window.Element.prototype.getBoundingClientRect = function () { return Object.assign({}, sizeRect); };
window.chrome = { storage: { local: { get: (k, cb) => cb({}), set: (o, cb) => cb && cb() } } };

const PROJ = path.resolve(__dirname, '..');
for (const f of ['src/common.js', 'src/extract.js', 'src/docxgen.js', 'build/docx.bundle.js']) {
  window.eval(fs.readFileSync(path.join(PROJ, f), 'utf8'));
}
const NS = window.xxtHelper;
if (!window.docx) throw new Error('docx bundle 没加载成功');

// 猜标题：优先命令行，其次页面上形如「2025春 xxx」的课程名
if (!title) {
  const text = (window.document.body.textContent || '').replace(/\s+/g, ' ');
  const m = text.match(/(20\d{2}\s*[春秋][^ ]{0,2}\s*[\u4e00-\u9fa5（）()A-Za-z]{2,30})/);
  title = m ? m[1].trim() : '学习通试卷复习';
}

const t0 = Date.now();
const qs = NS.extractFrom(window.document.body);
console.log('抽取:', qs.length, '题,', Date.now() - t0, 'ms');
if (!qs.length) { console.log('没抽到题目，退出'); process.exit(1); }

const stat = {
  noMy: qs.filter((q) => !q.myAnswer).length,
  noAns: qs.filter((q) => !q.answer).length,
  noAnalysis: qs.filter((q) => !q.analysis).length
};
console.log('统计:', JSON.stringify(stat));

NS.buildDocx(qs, {
  title,
  subtitle: '共 ' + qs.length + ' 题 · 来源：学习通试卷回顾页',
  withAnswer: true,
  withAnalysis: true,
  onlyWrong: false
}).then(async (blob) => {
  const buf = Buffer.from(await blob.arrayBuffer());
  fs.writeFileSync(out, buf);
  console.log('已写出:', out, buf.length, 'bytes  标题:', title);
  console.log('缺解析:', stat.noAnalysis, '/', qs.length);
}).catch((e) => {
  console.error('生成失败:', e && e.stack || e);
  process.exit(1);
});
