(function () {
  const out = [];
  ['showAnswer', 'answerList', 'popAnswerList', 'closeAnswers'].forEach((n) => {
    const f = window[n];
    out.push('==== ' + n + ' (' + typeof f + ') ====');
    if (typeof f === 'function') out.push(f.toString().slice(0, 2000));
  });
  out.push('---- 页面里调用这些函数的地方 ----');
  const html = document.documentElement.outerHTML;
  ['showAnswer', 'answerList(', 'popAnswerList'].forEach((k) => {
    let i = -1, cnt = 0;
    while ((i = html.indexOf(k, i + 1)) >= 0 && cnt < 3) {
      cnt++;
      out.push('[' + k + '] ...' + html.slice(Math.max(0, i - 200), i + 200).replace(/\s+/g, ' ') + '...');
    }
  });
  return out.join('\n');
})();
