(function () {
  const out = [];
  const STEM_PREFIX = new RegExp(
    '^\\s*(?:第\\s*\\d+\\s*题\\s*)?' +
      '(?:[（(【\\[]\\s*)?' +
      '(?:单项选择|多项选择|不定项选择|单选题|多选题|判断题|填空题|简答题|名词解释|论述题|计算题|分析题|匹配题|选择题)' +
      '(?:\\s*[,，、;；]?\\s*[\\d.]+\\s*分)?' +
      '\\s*(?:[）)】\\]]|$|[.、:：])'
  );
  const tests = [
    '(单选题, 4.0 分) 中国人民抗日战争',
    '(判断题, 4.0 分) xxx',
    '（单选题）xxx',
    '单选题：xxx'
  ];
  tests.forEach(function (t) {
    const m = t.match(STEM_PREFIX);
    out.push(JSON.stringify(t) + ' => ' + (m ? JSON.stringify(m[0]) + ' 剩余=' + JSON.stringify(t.slice(m[0].length)) : 'null'));
  });
  // 看 stripStem 实际走的分支
  out.push('---- stripStem 实际行为 ----');
  if (window.xxtHelper && window.xxtHelper.stripLeadingNumber) {
    const r = window.xxtHelper.stripLeadingNumber('1. (单选题, 4.0 分) 中国人民抗日战争');
    out.push('stripLeadingNumber => ' + JSON.stringify(r));
  }
  return out.join('\n');
})();
