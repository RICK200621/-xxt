(function () {
  const out = [];
  // 复制一份 extract.js 源码，把 finalize 里去重那行挖掉，重新 eval，看总数
  // 直接读源码不可行（页面拿不到文件），改为：用 extractFrom 拿结果 + 手工检查哪些块被边界吃掉

  // 换个思路：检查 7 个缺失块的题干，是否和前面的块「完全一致到 80 字」
  const ids = ['214104388', '214104410', '214104413', '214104438', '214104449', '214104451', '214104457'];
  const all = [...document.querySelectorAll('.questionLi')];

  function stemOf(el) {
    const s = el.querySelector('.qtContent');
    return s ? s.innerText.trim().replace(/\s+/g, '') : '';
  }
  function ansOf(el) {
    const s = el.querySelector('.rightAnswerContent');
    return s ? s.innerText.trim() : '';
  }
  function myOf(el) {
    const s = el.querySelector('.stuAnswerContent');
    return s ? s.innerText.trim() : '';
  }
  function optKeyOf(el) {
    return [...el.querySelectorAll('.mark_letter li')].map(function (l) { return l.innerText.trim(); }).join('|');
  }

  out.push('==== 7 个缺失块的完整去重键 ====');
  const keys = {};
  all.forEach(function (el) {
    const id = el.getAttribute('data');
    const k = stemOf(el).slice(0, 80) + '#' + ansOf(el) + '#' + myOf(el) + '#' + optKeyOf(el);
    (keys[k] = keys[k] || []).push(id);
  });

  ids.forEach(function (id) {
    const el = all.find(function (x) { return x.getAttribute('data') === id; });
    if (!el) { out.push(id + ' 找不到'); return; }
    const k = stemOf(el).slice(0, 80) + '#' + ansOf(el) + '#' + myOf(el) + '#' + optKeyOf(el);
    out.push(id + ' 键所在组: ' + JSON.stringify(keys[k]));
  });

  out.push('\n==== 重复键组（同一键多块）====');
  let dup = 0;
  Object.keys(keys).forEach(function (k) {
    if (keys[k].length > 1) { dup++; out.push('  x' + keys[k].length + ': ' + keys[k].join(', ') + ' | 键=' + JSON.stringify(k.slice(0, 100))); }
  });
  out.push('重复键组数=' + dup + ' / 唯一键数=' + Object.keys(keys).length + ' / 总块=' + all.length);
  return out.join('\n');
})();
