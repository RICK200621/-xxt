(function () {
  const out = [];
  const NS = window.xxtHelper;
  const qs = NS.extractFrom(document.body);
  out.push('抽出=' + qs.length);
  out.push('parseContainer 丢弃=' + ((NS._lastDropped || []).length));
  const fd = NS._lastFinalDropped || [];
  out.push('finalize 丢弃=' + fd.length);
  fd.slice(0, 20).forEach(function (x) { out.push('  ' + x); });
  return out.join('\n');
})();
