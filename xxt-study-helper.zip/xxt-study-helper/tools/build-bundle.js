// 把 docx 的 UMD 打包成一个可在 content script 里直接跑的 bundle，
// 并给依赖里的 setImmediate 打补丁（Chrome 页面环境没有它）。
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const raw = fs.readFileSync(path.join(root, 'vendor', 'docx.umd.js'), 'utf8');

if (!raw.includes('setImmediate(')) {
  console.warn('[warn] 没在 docx UMD 里找到 setImmediate，补丁可能不需要');
}

// 1) 给 JSZip 的 delay 用上 setImmediate 的地方加兜底
let patched = raw.replace(
  /setImmediate\(function\(\)\s*\{/g,
  '(typeof setImmediate === "function" ? setImmediate : function (f) { (window.setTimeout || setTimeout)(f, 0); })(function () {'
);
// 2) 把 setImmediate 挂到打包时用到的 globalThis 上
const header =
  'var __docx_g = {};\n(function () {\n' +
  '  var globalThis = __docx_g; var self = __docx_g;\n' +
  '  if (typeof __docx_g.setImmediate !== "function") { __docx_g.setImmediate = function (f) { (typeof window !== "undefined" && window.setTimeout ? window.setTimeout : setTimeout)(f, 0); }; }\n';
const footer = '\n})();\nwindow.docx = __docx_g.docx;\n';

const out = header + patched + footer;
fs.writeFileSync(path.join(root, 'build', 'docx.bundle.js'), out, 'utf8');
console.log('build/docx.bundle.js 写入完成：', out.length, 'bytes');
