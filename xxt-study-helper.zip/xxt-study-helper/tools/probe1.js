(function () {
  const out = [];
  out.push('title: ' + document.title);
  out.push('frames: ' + window.frames.length);
  const body = document.body;
  out.push('bodyTextLen: ' + (body.innerText || '').length);
  out.push('bodyTextHead: ' + JSON.stringify((body.innerText || '').replace(/\s+/g, ' ').slice(0, 600)));

  // 统计候选 class
  const sels = ['.questionLi', '.question-item', '.questionItem', '.mark_item', '.TiMu', '.AiTiMu',
    '[data-questionid]', '[data-question-id]', '.subject', '.queBox', '.question', '.topic-item',
    '.ti-item', '.singleQuesId', '.mark_answer', '.answerList', '.mark_name', '.examQuestionLi',
    '.questionWrap', '.ans-cc', '.Zy_TItle', '.TiMuWrap'];
  out.push('---- 选择器命中 ----');
  for (const s of sels) {
    try { out.push(s + ' -> ' + document.querySelectorAll(s).length); } catch (e) { out.push(s + ' -> err'); }
  }

  // 找 iframe
  out.push('---- iframe ----');
  document.querySelectorAll('iframe,frame').forEach((f, i) => {
    out.push(i + ': ' + f.src + ' | id=' + f.id + ' class=' + f.className);
  });

  // 看是否有关键字样
  const t = body.innerText || '';
  out.push('---- 关键字 ----');
  ['正确答案', '我的答案', '你的答案', '解析', '单选题', '多选题', '判断题'].forEach((k) => {
    out.push(k + ': ' + t.split(k).length - 1);
  });

  return out.join('\n');
})();
