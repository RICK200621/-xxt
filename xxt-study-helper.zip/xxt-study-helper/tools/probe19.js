(function () {
  const out = [];
  const el = document.querySelector('.questionLi');
  if (!el) return '无 .questionLi';

  // 复刻 parseContainer 的关键步骤
  const optZoneSel = '.answerList, .optionList, .answer_list, [class*="option"], [class*="answerList"], ul.list, dl';
  out.push('选项区选择器命中数=' + el.querySelectorAll(optZoneSel).length);
  const cl = el.cloneNode(true);
  if (el.querySelector(optZoneSel)) {
    cl.querySelectorAll(optZoneSel).forEach(function (n) { n.remove(); });
  }
  const stemEl = cl.querySelector('.mark_name, .stem, .questionStem, .question-content, .Zy_TItle, h1, h2, h3, .title');
  out.push('stemEl=' + (stemEl ? stemEl.className : 'null') + ' text=' + JSON.stringify(stemEl ? (stemEl.innerText || stemEl.textContent || '') : ''));

  // 选项
  const wraps = [...el.querySelectorAll('li')].filter(function (x) {
    return !x.querySelector('input[type=radio],input[type=checkbox],img,table,ul,dl');
  });
  out.push('li 候选=' + wraps.length);
  wraps.slice(0, 5).forEach(function (w, i) {
    out.push('  li[' + i + '] text=' + JSON.stringify(w.innerText));
  });

  // readLabeledText 逻辑
  const nodes = el.querySelectorAll('span,a,div,p,em,strong,b,i,font,li,dt,dd,label,td,th');
  out.push('readLabeledText 遍历节点数=' + nodes.length);
  let hits = 0;
  nodes.forEach(function (n) {
    const t = (n.textContent || '').trim();
    if (t.length > 40) return;
    if (/^(我的答案|正确答案|你的答案)\s*[：:]/.test(t)) {
      if (hits < 5) out.push('  命中: ' + JSON.stringify(t) + ' isConnected=' + n.isConnected);
      hits++;
    }
  });
  out.push('标签命中=' + hits);
  return out.join('\n');
})();
