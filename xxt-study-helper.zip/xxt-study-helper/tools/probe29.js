(function () {
  const out = [];
  const body = document.body.innerText;
  out.push('==== 含"解析"的上下文 ====');
  let i = -1, n = 0;
  while ((i = body.indexOf('解析', i + 1)) >= 0 && n < 5) {
    n++;
    out.push('[' + n + '] ...' + JSON.stringify(body.slice(Math.max(0, i - 200), i + 300)));
  }
  out.push('==== AI讲解 出现次数 ====');
  out.push(String(body.split('AI讲解').length - 1));

  out.push('==== 常见容器 class 命中统计 ====');
  const sels = ['.questionLi', '.TiMu', '.AiTiMu', '.mark_item', '.subject', '.Cy_TItle', '.Zy_TItle',
    '.mark_name', '.mark_letter', '.mark_answer', '.stuAnswerContent', '.rightAnswerContent', '.qtAnalysis',
    '.analysis', '[data-questionid]', '.question-item', '.answerList', '.aiAnalysis'];
  sels.forEach(function (s) {
    let c = 0;
    try { c = document.querySelectorAll(s).length; } catch (e) { c = -1; }
    out.push('  ' + s + ' = ' + c);
  });

  out.push('==== 第一个题的完整 HTML（猜测容器）====');
  // 找包含"我的答案"和"正确答案"的最小重复块
  const all = [...document.querySelectorAll('div,li,dl,section')];
  const cand = all.filter(function (el) {
    const t = el.innerText || '';
    return t.includes('我的答案') && t.includes('正确答案') && t.length < 6000;
  });
  out.push('候选块数量=' + cand.length);
  if (cand.length) {
    // 取最内层（不包含其它候选）
    const inner = cand.filter(function (el) { return !cand.some(function (o) { return o !== el && el.contains(o); }); });
    out.push('最内层候选=' + inner.length);
    out.push('---- 第一个最内层块 HTML ----');
    out.push(inner[0].outerHTML.slice(0, 3000));
  }
  return out.join('\n');
})();
