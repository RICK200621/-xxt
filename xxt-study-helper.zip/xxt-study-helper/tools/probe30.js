(function () {
  const out = [];
  const el = document.querySelector('.questionLi');
  out.push('==== 第一题 .questionLi 完整 HTML ====');
  out.push(el.outerHTML.slice(0, 4000));

  out.push('\n==== innerText ====');
  out.push(JSON.stringify(el.innerText));

  out.push('\n==== element-invisible-hidden 的样式 ====');
  const hidden = document.querySelectorAll('.element-invisible-hidden');
  out.push('数量=' + hidden.length);
  if (hidden.length) {
    const cs = getComputedStyle(hidden[0]);
    const r = hidden[0].getBoundingClientRect();
    out.push('display=' + cs.display + ' visibility=' + cs.visibility + ' opacity=' + cs.opacity +
      ' position=' + cs.position + ' clip=' + cs.clip + ' overflow=' + cs.overflow +
      ' width=' + cs.width + ' height=' + cs.height + ' rect=' + Math.round(r.width) + 'x' + Math.round(r.height) +
      ' textIndent=' + cs.textIndent + ' fontSize=' + cs.fontSize);
  }
  return out.join('\n');
})();
