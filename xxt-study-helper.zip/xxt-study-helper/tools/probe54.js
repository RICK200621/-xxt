(function () {
  const out = [];
  const frames = [{ win: window, doc: document, depth: 0 }];
  out.push('frames.length=' + frames.length);
  out.push('JSON=' + JSON.stringify(frames.map(function (f) { return { hasWin: !!f.win, hasDoc: !!f.doc, keys: Object.keys(f) }; })));
  for (const f of frames) {
    out.push('f=' + String(f) + ' | typeof f.win=' + typeof f.win + ' | f.w=' + typeof f.w);
  }
  // 直接访问
  out.push('frames[0].win === window : ' + (frames[0].win === window));
  out.push('window.xxtHelper 存在: ' + (typeof window.xxtHelper));
  return out.join('\n');
})();
