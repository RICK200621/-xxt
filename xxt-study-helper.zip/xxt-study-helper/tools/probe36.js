(function () {
  const out = [];
  const el = document.getElementById('question214104388');

  // 直接调 extractFrom 只传这个块
  const one = window.xxtHelper.extractFrom(el.parentElement);
  out.push('父容器 extractFrom 结果题数=' + one.length);
  one.forEach(function (q, i) {
    out.push('  [' + i + '] id=' + q.rawId + ' stem=' + JSON.stringify(q.stem.slice(0, 40)) + ' ans=' + JSON.stringify(q.answer));
  });

  // 单独传这个块自己（scope 就是它，querySelectorAll 不含自身，所以要包一层）
  const wrap = document.createElement('div');
  wrap.appendChild(el.cloneNode(true));
  document.body.appendChild(wrap);
  const two = window.xxtHelper.extractFrom(wrap);
  out.push('\n包一层后 extractFrom=' + two.length);
  two.forEach(function (q, i) {
    out.push('  [' + i + '] id=' + q.rawId + ' stem=' + JSON.stringify(q.stem.slice(0, 40)) +
      ' opts=' + q.options.length + ' my=' + JSON.stringify(q.myAnswer) + ' ans=' + JSON.stringify(q.answer));
  });
  wrap.remove();

  // 检查 extractFrom 的整页结果里，有没有 id 214104388
  const all = window.xxtHelper.extractFrom(document.body);
  out.push('\n整页结果含 214104388 = ' + all.some(function (q) { return String(q.rawId) === '214104388'; }));
  out.push('整页结果含 214104351 = ' + all.some(function (q) { return String(q.rawId) === '214104351'; }));
  const ids = all.map(function (q) { return String(q.rawId); });
  out.push('rawId 前 20 个: ' + ids.slice(0, 20).join(','));
  return out.join('\n');
})();
