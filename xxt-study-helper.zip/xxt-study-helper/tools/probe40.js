(function () {
  const out = [];
  // 用 monkey patch 方式：把 finalize 前后的数量打印出来
  // 但 finalize 是闭包内部函数，取不到。改用重演：手动跑每个 CONTAINER_SEL
  const NS = window.xxtHelper;
  const src = String(NS.extractFrom);

  // 直接自己写一份等价逻辑
  const CONTAINER_SELS = ['.questionLi', '.question-item', '.questionItem', '.mark_item', '.TiMu', '.AiTiMu',
    '[data-questionid]', '[data-question-id]', '.subject', '.queBox', '.question', '.topic-item', '.ti-item', '.singleQuesId'];

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const st = getComputedStyle(el);
    if (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 || r.height > 0;
  }

  const results = {};
  for (const sel of CONTAINER_SELS) {
    let els = [];
    try {
      els = [...document.body.querySelectorAll(sel)].filter(isVisible);
    } catch (e) { continue; }
    if (!els.length) continue;
    els = els.filter(function (el) { return !els.some(function (o) { return o !== el && o.contains(el); }); });
    const ids = els.map(function (el) { return el.getAttribute('data') || el.id; });
    const has38 = ids.some(function (x) { return String(x).indexOf('214104388') >= 0; });
    results[sel] = { afterVisible: els.length, has38: has38 };
  }
  out.push('==== 各选择器在 isVisible + contains 过滤后的数量 ====');
  Object.keys(results).forEach(function (k) {
    out.push('  ' + k + ' => ' + results[k].afterVisible + ' | 含38=' + results[k].has38);
  });

  // 手动 parseContainer 复刻，只做「能不能出 stem」
  out.push('\n==== 逐块检查 stem 能否解析 ====');
  const all = [...document.querySelectorAll('.questionLi')];
  out.push('总块数=' + all.length);
  return out.join('\n');
})();
