(function () {
  const out = [];
  const url = '/exam-ans/exam/test/reVersionPaperMarkContentNew?courseId=255245407&classId=128925575&p=1&id=169550368&ut=s&openc=807f581a17de304191ec9136c3fd1f64&times=1&newMooc=true';
  return new Promise(function (resolve) {
    const t = setTimeout(function () { out.push('TIMEOUT'); resolve(out.join('\n')); }, 20000);
    jQuery.ajax({
      type: 'get', url: url, dataType: 'html',
      success: function (data) {
        clearTimeout(t);
        const s = String(data);
        // 去掉注释后再判断
        const nc = s.replace(/<!--[\s\S]*?-->/g, '');
        out.push('去注释后 含正确答案:' + /正确答案/.test(nc) + ' 含答案解析:' + /答案解析/.test(nc) + ' 含"解析:"' + /解析\s*[:：]/.test(nc));
        const idx = [];
        let i = -1;
        while ((i = nc.indexOf('正确答案', i + 1)) >= 0) idx.push(i);
        out.push('正确答案出现次数(去注释)=' + idx.length);
        idx.slice(0, 3).forEach(function (p) {
          out.push('---- @' + p + ' ----');
          out.push(nc.slice(Math.max(0, p - 700), p + 900));
        });
        const j = nc.indexOf('解析');
        if (j >= 0) {
          out.push('---- 第一个"解析" @' + j + ' ----');
          out.push(nc.slice(Math.max(0, j - 500), j + 800));
        }
        resolve(out.join('\n'));
      },
      error: function (xhr, st, e) { clearTimeout(t); out.push('ERR ' + st + ' ' + (xhr && xhr.status)); resolve(out.join('\n')); }
    });
  });
})();
