(function () {
  const out = [];
  const NS = window.xxtHelper;

  // 拿一个缺失的块单独解析，看它为什么被丢掉
  const el = document.getElementById('question214104388');
  out.push('==== 缺失块 HTML ====');
  out.push(el.outerHTML.slice(0, 3000));

  // 复刻 parseContainer 的选项部分
  const SEARCH_ANY = 'input[type=radio],input[type=checkbox]';
  const OPTION_WRAP_SEL = ['[data-key][data-index]', 'label', 'li', '.item', '.option', '.answer', 'dd', 'tr'];
  out.push('\n==== 逐选择器命中 ====');
  OPTION_WRAP_SEL.forEach(function (s) {
    const found = [...el.querySelectorAll(s)].filter(function (x) {
      return !x.querySelector('input[type=radio],input[type=checkbox],img,table,ul,dl');
    });
    out.push('  ' + s + ' => filtered ' + found.length + ' / raw ' + el.querySelectorAll(s).length);
  });

  const lis = [...el.querySelectorAll('li')];
  out.push('\nli 明细:');
  lis.forEach(function (li, i) {
    out.push('  [' + i + '] ' + JSON.stringify(li.innerText) + ' | 子元素含img=' + !!li.querySelector('img'));
  });

  // 每题的选项数分布
  const qs = NS.extractFrom(document.body);
  const dist = {};
  qs.forEach(function (q) { dist[q.options.length] = (dist[q.options.length] || 0) + 1; });
  out.push('\n抽出题目 选项数分布: ' + JSON.stringify(dist));
  return out.join('\n');
})();
