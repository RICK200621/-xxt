(function () {
  const out = [];
  const NS = window.xxtHelper;
  const all = [...document.querySelectorAll('.questionLi')];
  out.push('DOM 块数=' + all.length);

  // 直接逐块调用内部逻辑不可行，改为：收集所有块的题干，检查重复
  const stems = all.map(function (el, i) {
    const nm = el.querySelector('.mark_name');
    const num = nm ? (nm.innerText.match(/^\s*(\d+)\./) || [])[1] : '';
    const stemEl = el.querySelector('.qtContent');
    const stem = stemEl ? stemEl.innerText.trim() : '';
    const li = [...el.querySelectorAll('.mark_letter li')];
    return { i: i, id: el.getAttribute('data'), num: Number(num), stem: stem, optN: li.length };
  });

  // 找重复题干
  out.push('==== 重复题干 ====');
  const seen = {};
  stems.forEach(function (s) {
    const k = s.stem.replace(/\s+/g, '');
    (seen[k] = seen[k] || []).push(s);
  });
  let dups = 0;
  Object.keys(seen).forEach(function (k) {
    if (seen[k].length > 1) {
      dups++;
      out.push('  重复 x' + seen[k].length + ': ' + JSON.stringify(k.slice(0, 50)));
      seen[k].forEach(function (s) { out.push('     #' + s.num + ' id=' + s.id + ' optN=' + s.optN); });
    }
  });
  out.push('重复题干组数=' + dups);

  // 抽出后实际丢失的
  const qs = NS.extractFrom(document.body);
  out.push('\n抽出=' + qs.length + ' / DOM=' + all.length + ' 差=' + (all.length - qs.length));
  return out.join('\n');
})();
