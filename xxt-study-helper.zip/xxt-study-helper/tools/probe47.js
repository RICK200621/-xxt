(function () {
  const out = [];
  const NS = window.xxtHelper;
  const scope = document.body;
  const SEARCH_ANY = 'input[type=radio],input[type=checkbox]';

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    const st = getComputedStyle(el);
    if (st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
    if (st.position === 'fixed' && /translate\(-?[1-9]\d{2,}px/.test(st.transform || '')) return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 || r.height > 0;
  }

  const SELS = ['.questionLi', '.singleQuesId'];
  SELS.forEach(function (sel) {
    let els = [...scope.querySelectorAll(sel)].filter(isVisible);
    els = els.filter(function (el) { return !els.some(function (o) { return o !== el && o.contains(el); }); });
    out.push('=== ' + sel + ' 块数=' + els.length + ' ===');
    // 逐个调 extractFrom 单块，统计失败
    const fails = [];
    els.forEach(function (el, i) {
      const w = document.createElement('div');
      document.body.appendChild(w);
      w.appendChild(el.cloneNode(true));
      let got = [];
      try { got = NS.extractFrom(w); } catch (e) { got = []; }
      w.remove();
      if (got.length !== 1) fails.push((el.getAttribute('data') || i) + ':' + got.length);
    });
    out.push('  单块失败=' + fails.length + ' ' + fails.slice(0, 10).join(','));
  });
  return out.join('\n');
})();
