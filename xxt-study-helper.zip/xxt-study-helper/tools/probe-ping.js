(function () {
  return 'exec ok, location=' + location.href + ' title=' + document.title + ' questionLi=' + document.querySelectorAll('.questionLi').length;
})();
