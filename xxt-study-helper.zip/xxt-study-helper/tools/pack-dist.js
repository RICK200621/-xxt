// 打包 dist：把源码和已构建的 bundle 复制到 dist/，方便在 edge://extensions 里"加载解压缩的扩展"
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const DIST = path.join(ROOT, 'dist');

function rm(p) {
  if (fs.existsSync(p)) fs.rmSync(p, { recursive: true, force: true });
}

function copy(src, dst) {
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  fs.copyFileSync(src, dst);
  const h = require('crypto').createHash('sha256').update(fs.readFileSync(dst)).digest('hex').slice(0, 12);
  console.log('  ' + path.relative(ROOT, dst) + '  ' + h);
}

rm(DIST);
fs.mkdirSync(DIST, { recursive: true });

const files = [
  'manifest.json',
  'background.js',
  'src/common.js',
  'src/extract.js',
  'src/docxgen.js',
  'src/ui.js',
  'build/docx.bundle.js',
  'icons/icon16.png',
  'icons/icon32.png',
  'icons/icon48.png',
  'icons/icon128.png'
];

let missing = 0;
for (const f of files) {
  const s = path.join(ROOT, f);
  if (!fs.existsSync(s)) { console.log('  缺失: ' + f); missing++; continue; }
  copy(s, path.join(DIST, f));
}
// 说明文档也带上
for (const f of ['安装说明.md']) {
  const s = path.join(ROOT, f);
  if (fs.existsSync(s)) copy(s, path.join(DIST, f));
}

console.log('\ndist 打包完成，文件数: ' + fs.readdirSync(DIST, { recursive: true }).filter((x) => fs.statSync(path.join(DIST, x)).isFile()).length + (missing ? '，缺失 ' + missing : ''));
