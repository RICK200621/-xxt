(function () {
  const out = [];
  const el = document.querySelector('.questionLi');
  const SEARCH_ANY = 'input[type=radio],input[type=checkbox]';
  const OPTION_WRAP_SEL = ['[data-key][data-index]', 'label', 'li', '.item', '.option', '.answer', 'dd', 'tr'];
  out.push('options 长度=' + el.querySelectorAll(SEARCH_ANY).length);
  out.push('el.querySelector(SEARCH_ANY) 非空=' + !!el.querySelector(SEARCH_ANY));
  out.push('el.querySelector("input,img,table,ul,dl") 非空=' + !!el.querySelector('input,img,table,ul,dl'));
  out.push('ul 数量=' + el.querySelectorAll('ul').length);
  OPTION_WRAP_SEL.forEach(function (s) {
    const found = [...el.querySelectorAll(s)].filter(function (x) {
      return !x.querySelector('input[type=radio],input[type=checkbox],img,table,ul,dl');
    });
    out.push('  ' + s + ' => ' + found.length + ' / raw ' + el.querySelectorAll(s).length);
  });
  return out.join('\n');
})();
