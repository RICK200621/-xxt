(function () {
  const out = [];
  out.push('url=' + location.href.slice(0, 100));
  out.push('xxtHelper=' + (typeof window.xxtHelper));
  if (window.xxtHelper) {
    out.push('keys=' + Object.keys(window.xxtHelper).join(','));
    out.push('ready=' + window.xxtHelper.ready + ' extract=' + window.xxtHelper.extract + ' uiReady=' + window.xxtHelper.uiReady);
  }
  const btn = document.querySelector('.xxh-fab,.xxh-btn,[class*="xxh"]');
  out.push('页面 UI 元素: ' + (btn ? btn.className : '无'));
  out.push('body 前 200 字: ' + (document.body ? document.body.innerText.slice(0, 200).replace(/\n/g, ' | ') : ''));
  return out.join('\n');
})();
