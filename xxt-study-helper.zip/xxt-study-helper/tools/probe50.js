(function () {
  const out = [];
  const NS = window.xxtHelper;
  NS._selLog = [];
  NS._lastDropped = [];
  const qs = NS.extractFrom(document.body);
  out.push('抽出=' + qs.length);
  out.push('各选择器 [名字, 块数, 解析成功] :');
  (NS._selLog || []).forEach(function (x) { out.push('  ' + JSON.stringify(x)); });
  out.push('丢弃明细:');
  (NS._lastDropped || []).slice(0, 30).forEach(function (x) { out.push('  ' + x); });
  return out.join('\n');
})();
