(function () {
  const out = [];
  // 1. 考试详情页 look 里有啥
  const lookUrl = 'https://mooc1.chaoxing.com/exam-ans/exam/test/look?courseId=255245407&classId=128925575&examId=7877691&examAnswerId=169550368&cpi=415894527';
  return new Promise(function (resolve) {
    jQuery.ajax({
      type: 'get', url: lookUrl, dataType: 'html', timeout: 15000,
      success: function (data) {
        const s = String(data);
        const nc = s.replace(/<!--[\s\S]*?-->/g, '');
        out.push('==== look 页 ====  len=' + s.length);
        out.push('含"查看试卷":' + /查看试卷/.test(nc) + '  含"重做":' + /重做/.test(nc) + ' 含"答案":' + /答案/.test(nc) + ' 含"解析":' + /解析/.test(nc));
        // 抽取所有链接
        const hrefs = [];
        const re = /<a[^>]*href="([^"]*)"[^>]*>([\s\S]*?)<\/a>/g;
        let m;
        while ((m = re.exec(nc)) && hrefs.length < 40) {
          const txt = m[2].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
          if (txt) hrefs.push(txt + ' => ' + m[1].slice(0, 200));
        }
        out.push(hrefs.join('\n'));
        // 文本
        const tmp = document.createElement('div');
        tmp.innerHTML = nc;
        out.push('---- 正文 ----');
        out.push((tmp.innerText || '').replace(/\n{2,}/g, '\n').slice(0, 1500));
        resolve(out.join('\n'));
      },
      error: function (xhr, st) { out.push('ERR ' + st); resolve(out.join('\n')); }
    });
  });
})();
