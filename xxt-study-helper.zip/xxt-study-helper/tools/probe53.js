(function () {
  const out = [];
  const NS = window.xxtHelper;
  out.push('NS.extractFrom 类型: ' + typeof NS.extractFrom);

  // 1) 直接抽 body
  try {
    const qs = NS.extractFrom(document.body);
    out.push('extractFrom(document.body) = ' + qs.length);
  } catch (e) {
    out.push('extractFrom 抛异常: ' + e.message);
  }

  // 2) 复刻 collectFrames
  let frames = [];
  try {
    frames = [{ win: window, doc: document, depth: 0 }];
    let i = 0;
    while (i < frames.length) {
      const f = frames[i++];
      let iframes = [];
      try { iframes = [...f.doc.querySelectorAll('iframe,frame')]; } catch (e) { iframes = []; }
      for (const ifr of iframes) {
        let w = null, d = null;
        try {
          w = ifr.contentWindow;
          d = w && w.document;
          if (d && d.readyState === 'uninitialized') d = null;
        } catch (e) { d = null; }
        if (w && d) frames.push({ win: w, doc: d, depth: f.depth + 1 });
      }
    }
    out.push('collectFrames 数量: ' + frames.length);
  } catch (e) {
    out.push('collectFrames 抛异常: ' + e.message);
  }

  // 3) 复刻 extractAll
  try {
    const groups = [];
    for (const f of frames) {
      const helper = f.w.xxtHelper;
      if (!helper || !helper.extractFrom) { out.push('  某帧没有 helper'); continue; }
      let qs;
      try { qs = helper.extractFrom(f.doc.body); } catch (e) { out.push('  帧抽取抛异常: ' + e.message); continue; }
      out.push('  帧抽取 = ' + (qs ? qs.length : 'null'));
      if (qs && qs.length) groups.push(qs);
    }
    out.push('groups = ' + groups.length);
    groups.sort((a, b) => b.length - a.length);
    const res = [];
    for (const g of groups) {
      for (const q of g) {
        const dup = res.some((x) => {
          if (x.rawId && q.rawId && x.rawId === q.rawId) return true;
          return x.stem && q.stem && (x.stem === q.stem || NS.similar(x.stem, q.stem) > 0.9);
        });
        if (!dup) res.push(q);
      }
    }
    out.push('extractAll 结果 = ' + res.length);
  } catch (e) {
    out.push('extractAll 抛异常: ' + e.message + ' | ' + (e.stack || '').split('\n').slice(0, 3).join(' <- '));
  }
  return out.join('\n');
})();
