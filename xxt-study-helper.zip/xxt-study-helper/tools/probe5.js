(function () {
  const out = [];
  const html = document.documentElement.outerHTML;
  out.push('docLen: ' + html.length);
  ['正确答案', '参考答案', '解析', 'answerList', 'mark_answer', 'showAnswer', '正确答案：'].forEach((k) => {
    out.push(k + ' 出现次数: ' + html.split(k).length - 1);
  });
  out.push('---- 查找可能隐藏的答案容器 ----');
  const cands = [...document.querySelectorAll('[style*="none"],[style*="visibility"],.hide,.hidden,[hidden]')];
  out.push('隐藏元素数量: ' + cands.length);
  cands.slice(0, 30).forEach((e) => out.push(e.tagName + '.' + (typeof e.className === 'string' ? e.className : '') + ' | ' + JSON.stringify((e.innerText || '').trim().slice(0, 80))));
  out.push('---- 是否有 script 里的答案数据 ----');
  const scripts = [...document.querySelectorAll('script:not([src])')];
  out.push('内联 script 数: ' + scripts.length);
  for (const s of scripts) {
    const t = s.textContent || '';
    if (/正确答案|answer/.test(t)) out.push('script 命中: ' + t.slice(0, 500));
  }
  return out.join('\n');
})();
