(function () {
  const h = document.querySelector('.mark_name');
  const courseEl = document.querySelector('.courseName,.course-name,h1,.mark_title');
  const opt = {
    title: document.title || '学习通试卷复习',
    subtitle: (courseEl ? courseEl.innerText.trim() + '｜' : '') + location.href.slice(0, 120),
    withAnswer: true,
    withAnalysis: true
  };
  const qs = window.xxtHelper.extractFrom(document.body);
  return window.xxtHelper.buildDocx(qs, opt).then(function (blob) {
    return new Promise(function (resolve) {
      const fr = new FileReader();
      fr.onload = function () {
        resolve('DOCX_BASE64:' + fr.result.split(',')[1]);
      };
      fr.readAsDataURL(blob);
    });
  });
})();
