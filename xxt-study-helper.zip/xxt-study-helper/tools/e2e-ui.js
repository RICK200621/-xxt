// 端到端测试页面 UI：把脚本按 content_scripts 顺序注入本地 fixture 页，
// 点一次「抓取本页题目」，检查预览面板是不是真的出题、toast 有没有报错。
// 说明：ui.js 里有一道「只在本站域名生效」的守卫，测试时把它去掉，其余逻辑全走真实代码。
// 用法: node tools/e2e-ui.js
const http = require('http');
const fs = require('fs');
const path = require('path');

const PROJ = path.join(__dirname, '..');
const URL_TEST = process.argv[2] || 'http://127.0.0.1:8765/test/fixture.html';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function getJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let d = '';
      res.on('data', (c) => (d += c));
      res.on('end', () => resolve(JSON.parse(d)));
    }).on('error', reject);
  });
}

function newTab(url) {
  return new Promise((resolve, reject) => {
    const req = http.request(
      { host: '127.0.0.1', port: 9222, method: 'PUT', path: '/json/new?' + encodeURIComponent(url) },
      (res) => {
        let d = '';
        res.on('data', (c) => (d += c));
        res.on('end', () => {
          try { resolve(JSON.parse(d)); } catch (e) { reject(e); }
        });
      }
    );
    req.on('error', reject);
    req.end();
  });
}

class CDP {
  constructor(wsUrl) { this.ws = new WebSocket(wsUrl); this.id = 0; this.pending = new Map(); }
  async open() {
    await new Promise((res, rej) => { this.ws.onopen = res; this.ws.onerror = rej; });
    this.ws.onmessage = (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) reject(new Error(JSON.stringify(msg.error)));
        else resolve(msg.result);
      }
    };
    return this;
  }
  send(method, params) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params: params || {} }));
    });
  }
  async eval(expr, awaitPromise) {
    const r = await this.send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: !!awaitPromise });
    if (r.exceptionDetails) throw new Error('页面异常: ' + JSON.stringify(r.exceptionDetails.exception || r.exceptionDetails));
    return r.result.value;
  }
  close() { this.ws.close(); }
}

(async () => {
  const page = await newTab(URL_TEST);
  console.log('新标签页:', page.url);
  const cdp = await new CDP(page.webSocketDebuggerUrl).open();
  await cdp.send('Page.enable');

  let cur = '';
  const wantPath = (URL_TEST.split('/').pop() || '').split('?')[0];
  for (let i = 0; i < 20; i++) {
    await sleep(400);
    try { cur = await cdp.eval('location.href', false); } catch (e) { cur = '?'; }
    if (cur.indexOf(wantPath) >= 0) break;
  }
  console.log('当前页:', cur, '| 标题:', await cdp.eval('document.title', false));
  if (cur.indexOf(wantPath) < 0) throw new Error('页面没加载成功: ' + cur);

  // content script 环境的最小 chrome.* 桩
  await cdp.eval(
    `window.chrome = { storage: { local: { _d: {},
        get: function (k) { const self=this; const key = typeof k==='string'?k:(k&&Object.keys(k)[0]);
          const out={}; if (self._d[key]!==undefined) out[key]=self._d[key]; return Promise.resolve(out); },
        set: function (obj) { Object.assign(this._d, obj); return Promise.resolve(); } } },
      runtime: { onMessage: { addListener: function(){ window.__msgListener = arguments[0]; } },
        sendMessage: function(m,cb){
          window.__lastMsg = { type: m && m.type, filename: m && m.filename,
            dataUrl: (m && m.dataUrl) || '',
            dataUrlLen: ((m && m.dataUrl) || '').length,
            dataUrlHead: ((m && m.dataUrl) || '').slice(0, 70) };
          if(cb) cb({ok:true});
        }, lastError: null } };
    window.addEventListener('error', function(e){ (window.__errs=window.__errs||[]).push(String(e.message)); });
   1`,
    false
  );

  const files = ['src/common.js', 'src/extract.js', 'src/docxgen.js', 'build/docx.bundle.js', 'src/ui.js'];
  const useDist = /dist/.test(process.argv[3] || '');
  if (useDist) console.log('（注入 dist 里的打包产物）');
  for (const f of files) {
    const rel = useDist ? 'dist/' + f : f;
    let code = fs.readFileSync(path.join(PROJ, rel), 'utf8');
    if (f === 'src/ui.js') {
      // 去掉测试站点的域名守卫（只影响测试，其余代码原样）
      code = code.replace(/if \(!\/\(chaoxing\|edu\\\.cn\|\\\.cx\$\)\/\.test\(host\)\) return;/, '/* 测试：跳过域名守卫 */');
      if (code.indexOf('测试：跳过域名守卫') < 0) console.log('⚠ ui.js 域名守卫没被替换，注意结果可能无效');
    }
    await cdp.eval(code, false);
  }
  await sleep(1600);

  console.log('版本:', await cdp.eval('window.xxtHelper && window.xxtHelper.VERSION', false));
  console.log('FAB 挂上没:', await cdp.eval('!!document.querySelector(".xxh-fab")', false));
  console.log('诊断:', await cdp.eval('JSON.stringify(window.xxtHelper.diagnose())', true));

  const clicked = await cdp.eval(
    `(function(){ var b=document.querySelector('.xxh-fab [data-act="capture"]'); if(b){ b.click(); return true; } return false; })()`,
    false
  );
  console.log('点了抓取按钮:', clicked);
  await sleep(2500);

  const res = await cdp.eval(
    `JSON.stringify({
      toast: (document.querySelector('.xxh-toast')||{}).textContent || '',
      panel: !!document.querySelector('.xxh-mask'),
      stat: (document.querySelector('#xxh-stat')||{}).textContent || '',
      ver: (document.querySelector('#xxh-ver')||{}).textContent || '',
      qCount: document.querySelectorAll('.xxh-q').length,
      firstStem: (document.querySelector('.xxh-stem')||{}).textContent || '',
      rows: [...document.querySelectorAll('.xxh-row')].slice(0,4).map(function(e){return e.textContent;}),
      errs: window.__errs || []
    }, null, 2)`,
    true
  );
  console.log('结果:', res);

  // 点「下载 Word」：主路径是在页面里 a[download] + blob:，所以拦下 click 记录 href，
  // 再把 blob 读回来验证字节（真下载由浏览器完成，这里只验内容）
  const dlBtn = await cdp.eval(
    `(function(){ var a=HTMLAnchorElement.prototype; if(!a.__patched){ a.__patched=true;
         a.click=function(){ window.__anchorClicked=(window.__anchorClicked||0)+1;
           window.__lastAnchor={ href:this.href, download:this.download }; };
       }
       var btn=document.querySelector('.xxh-mask [data-act="download"]'); if(btn) btn.click(); return !!btn; })()`,
    false
  );
  console.log('点了下载按钮:', dlBtn);
  await sleep(5000);
  console.log(
    '下载:',
    await cdp.eval(
      `JSON.stringify({ anchor: window.__lastAnchor ? { download: window.__lastAnchor.download, hrefHead: window.__lastAnchor.href.slice(0, 40) } : null,
         bgMsg: window.__lastMsg ? { type: window.__lastMsg.type, filename: window.__lastMsg.filename, dataUrlLen: window.__lastMsg.dataUrlLen } : null,
         anchorClicks: window.__anchorClicked || 0,
         toast: (document.querySelector('.xxh-toast')||{}).textContent || '' }, null, 2)`,
      true
    )
  );

  // 把 a[download] 指向的 blob 读回来，落成文件验证能不能打开
  const blobDataUrl = await cdp.eval(
    `(async function(){
       var h=(window.__lastAnchor&&window.__lastAnchor.href)||'';
       if(!h) return '';
       var r=await fetch(h); var b=await r.blob();
       return await new Promise(function(res){ var fr=new FileReader(); fr.onload=function(){ res(fr.result); }; fr.readAsDataURL(b); });
     })()`,
    true
  );
  if (blobDataUrl) {
    const b64 = blobDataUrl.slice(blobDataUrl.indexOf(',') + 1);
    const outFile = path.join(PROJ, 'build', '_e2e-download.docx');
    fs.writeFileSync(outFile, Buffer.from(b64, 'base64'));
    console.log('已还原下载文件:', outFile, fs.statSync(outFile).size, 'bytes');
  } else {
    console.log('⚠ 没拿到 a[download] 的 blob URL');
  }

  cdp.close();
})().catch((e) => { console.error(e); process.exit(1); });
