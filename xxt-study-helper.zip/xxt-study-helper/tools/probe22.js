(function () {
  const out = [];
  const el = document.querySelector('.questionLi');
  // 复刻 extract.js 的 stripStem
  const STEM_PREFIX = new RegExp(
    '^\\s*(?:第\\s*\\d+\\s*题\\s*)?[（(【\\[]?\\s*(?:单项选择|多项选择|不定项选择|单选题|多选题|判断题|填空题|简答题|名词解释|论述题|计算题|分析题|匹配题|选择题)\\s*[）)】\\]]?\\s*[.、:：]?\\s*'
  );
  const stemRaw = el.querySelector('.mark_name').innerText;
  out.push('stemRaw=' + JSON.stringify(stemRaw));
  const m = stemRaw.match(STEM_PREFIX);
  out.push('STEM_PREFIX match=' + (m ? JSON.stringify(m[0]) : 'null'));

  // stripLeadingNumber
  const t0 = stemRaw.replace(/^\s*/, '');
  const numM = t0.match(/^第\s*(\d+)\s*题\s*[.、．:：]?\s*/) || t0.match(/^(\d+)\s*[.、．)）]\s*/);
  out.push('题号匹配=' + (numM ? JSON.stringify(numM[0]) : 'null'));
  let rest = numM ? t0.slice(numM[0].length) : t0;
  out.push('去题号后=' + JSON.stringify(rest.slice(0, 50)));

  // 题型识别
  const m2 = rest.match(STEM_PREFIX);
  out.push('题型前缀匹配=' + (m2 ? JSON.stringify(m2[0]) : 'null'));

  // 真实走一遍 stripStem 结果
  out.push('---- 关键：括号是全角还是半角 ----');
  out.push('char code: ' + [...rest.slice(0, 12)].map(function (c) { return c + ':' + c.charCodeAt(0); }).join(' '));
  return out.join('\n');
})();
