(function () {
  const out = [];
  if (!window.xxtHelper || !window.xxtHelper.extractFrom) return 'xxtHelper 未就绪';
  const qs = window.xxtHelper.extractFrom(document.body);

  // 判断题（第16题）
  const judgeQs = qs.filter(function (q) { return q.type === '判断题'; });
  out.push('判断题数量=' + judgeQs.length);
  if (judgeQs[0]) out.push('判断题示例: ' + JSON.stringify({ stem: judgeQs[0].stem.slice(0, 50), opts: judgeQs[0].options, my: judgeQs[0].myAnswer }, null, 1));

  // 多选题
  const multi = qs.filter(function (q) { return q.type === '多选题'; });
  out.push('多选题数量=' + multi.length);
  if (multi[0]) out.push('多选题示例: ' + JSON.stringify({ my: multi[0].myAnswer, opts: multi[0].options.map(function (o) { return o.key; }) }));

  out.push('---- 全部题型分布 ----');
  const by = {};
  qs.forEach(function (q) { by[q.type] = (by[q.type] || 0) + 1; });
  out.push(JSON.stringify(by));
  out.push('---- 我的答案全量 ----');
  out.push(qs.map(function (q, i) { return (i + 1) + ':' + (q.myAnswer || '(空)'); }).join('  '));
  return out.join('\n');
})();
