const http = require('http');
const fs = require('fs');
const path = require('path');

function getJson(url) {
  return new Promise((resolve, reject) => {
    http.get(url, (res) => {
      let d = '';
      res.on('data', (c) => (d += c));
      res.on('end', () => resolve(JSON.parse(d)));
    }).on('error', reject);
  });
}

class CDP {
  constructor(wsUrl) { this.ws = new WebSocket(wsUrl); this.id = 0; this.pending = new Map(); }
  async open() {
    await new Promise((res, rej) => { this.ws.onopen = res; this.ws.onerror = rej; });
    this.ws.onmessage = (ev) => {
      const msg = JSON.parse(ev.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) reject(new Error(JSON.stringify(msg.error)));
        else resolve(msg.result);
      }
    };
    return this;
  }
  send(method, params) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params: params || {} }));
    });
  }
  async eval(expr, awaitPromise) {
    const r = await this.send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: !!awaitPromise });
    if (r.exceptionDetails) throw new Error('页面异常: ' + JSON.stringify(r.exceptionDetails.exception || r.exceptionDetails));
    return r.result.value;
  }
  close() { this.ws.close(); }
}

const PROJ = path.join(__dirname, '..');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 用法: node tools/cdp-fresh.js <匹配正则> <注入脚本1> [注入2 ...] -- <探测脚本>
(async () => {
  const argv = process.argv.slice(2);
  const sep = argv.indexOf('--');
  const match = argv[0];
  const injects = sep > 0 ? argv.slice(1, sep) : [];
  const probeFile = sep > 0 ? argv[sep + 1] : null;

  const list = await getJson('http://127.0.0.1:9222/json/list');
  const pages = list.filter((p) => p.type === 'page' && new RegExp(match).test(p.url));
  if (!pages.length) { console.log('没有匹配的标签页'); process.exit(1); }
  const t = pages[0];
  console.log('标签页:', t.title, '|', t.url.slice(0, 110));

  const cdp = await new CDP(t.webSocketDebuggerUrl).open();
  await cdp.send('Page.enable');
  await cdp.send('Page.reload', { ignoreCache: true });
  await sleep(6000);

  // 清掉可能残留的旧命名空间
  await cdp.eval('try{delete window.xxtHelper}catch(e){};1', false);

  for (const f of injects) {
    const code = fs.readFileSync(path.join(PROJ, f), 'utf8');
    await cdp.eval(code, false);
    console.log('已注入:', f);
  }

  if (probeFile) {
    const code = fs.readFileSync(path.join(PROJ, probeFile), 'utf8');
    const out = await cdp.eval(code, true);
    console.log(typeof out === 'string' ? out : JSON.stringify(out, null, 2));
  }
  cdp.close();
})().catch((e) => { console.error(e); process.exit(1); });
