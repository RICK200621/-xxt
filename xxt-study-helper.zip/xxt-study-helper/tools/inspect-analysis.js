// 细看保存页面里解析相关结构：class="analysis"、qtAnalysis、AI讲解按钮
const fs = require('fs');
const file = process.argv[2];
const html = fs.readFileSync(file, 'utf8');

function show(label, re, times = 3, ctx = 260) {
  console.log('\n=== ' + label + ' ===');
  let m;
  let n = 0;
  while ((m = re.exec(html)) && n < times) {
    const s = Math.max(0, m.index - ctx / 3);
    console.log('--- @' + m.index + ' ---');
    console.log(html.slice(s, m.index + ctx).replace(/\s+/g, ' '));
    n++;
  }
  if (!n) console.log('(无)');
}

show('class="analysis" 出现处', /class="[^"]*\banalysis\b[^"]*"/g, 3, 400);
show('qtAnalysis 出现处', /qtAnalysis/g, 3, 400);
show('AI讲解 按钮', /AI讲解/g, 2, 400);
show('包含「解析」的上下文', /解析/g, 4, 300);

// 找出唯一那个 element-invisible-hidden 与 2 个 qtAnalysis 的位置关系
console.log('\n=== 检查是否有「展开/查看解析」类按钮 ===');
for (const kw of ['查看解析', '展开解析', '收起', '展开', 'analysisBtn', 'showAnalysis', 'qtAnalysisContent', 'analysisContent']) {
  const n = (html.match(new RegExp(kw, 'g')) || []).length;
  console.log('  ' + kw.padEnd(20) + n);
}
