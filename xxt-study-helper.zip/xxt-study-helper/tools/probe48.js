(function () {
  const out = [];
  // 用 monkey-patch 拦截：拿 extract.js 的源码不可行，
  // 改为在页面里请求 chrome-extension:// 的脚本？不行。
  // 直接看 NS 上暴露的内部函数有没有
  const NS = window.xxtHelper;
  out.push('NS 的键: ' + Object.keys(NS).join(', '));
  out.push('_lastDropped: ' + JSON.stringify((NS._lastDropped || []).slice(0, 5)));
  out.push('_lastFinalDropped: ' + JSON.stringify((NS._lastFinalDropped || []).slice(0, 5)));

  // 关键实验：传 document.body 时的耗时和结果，再传一个只包 180 个块的容器
  const t1 = performance.now();
  const r1 = NS.extractFrom(document.body);
  const d1 = performance.now() - t1;
  out.push('\nbody 抽取: ' + r1.length + ' 题, ' + Math.round(d1) + 'ms');

  // 构造一个包含全部 180 块的干净容器
  const box = document.createElement('div');
  [...document.querySelectorAll('.questionLi')].forEach(function (el) {
    box.appendChild(el.cloneNode(true));
  });
  document.body.appendChild(box);
  const r2 = NS.extractFrom(box);
  out.push('干净容器抽取: ' + r2.length + ' 题');
  out.push('干净容器 finalize 丢弃=' + (NS._lastFinalDropped || []).length);
  if ((NS._lastFinalDropped || []).length) out.push('  ' + JSON.stringify(NS._lastFinalDropped.slice(0, 10)));
  box.remove();

  const ids1 = new Set(r1.map(function (q) { return String(q.rawId); }));
  const ids2 = new Set(r2.map(function (q) { return String(q.rawId); }));
  out.push('\nbody 有但容器没有: ' + [...ids2].filter(function (x) { return !ids1.has(x); }).join(','));
  out.push('容器有但 body 没有: ' + [...ids1].filter(function (x) { return !ids2.has(x); }).join(','));
  return out.join('\n');
})();
