// 找试卷标题/课程名在 DOM 里的位置，供 ui.js 猜导出文件名
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync(process.argv[2], 'utf8');
const { window } = new JSDOM(html, { runScripts: 'outside-only' });
const doc = window.document;
console.log('title:', doc.title);

const sels = [
  '.mark_title', '.examName', '.courseName', '.course-name', '.paperName',
  '.head h1', 'h1', 'h2', '.mark_title_name', '.title', '#title', '.subjectName',
  '.zt_title', '.exam-title', '.paper-title'
];
for (const s of sels) {
  let els = [];
  try { els = [...doc.querySelectorAll(s)].slice(0, 3); } catch (e) { continue; }
  if (!els.length) continue;
  console.log('\n选择器 ' + s + ' 命中 ' + doc.querySelectorAll(s).length);
  els.forEach((e) => console.log('   [' + e.className + '] ' + (e.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 120)));
}

const body = doc.body.textContent.replace(/\s+/g, ' ');
const i = body.indexOf('题量');
console.log('\n--- 正文「题量」附近 ---');
console.log(body.slice(Math.max(0, i - 220), i + 160));

const m = body.match(/(20\d{2}\s*[春秋]\s*[\u4e00-\u9fa5（）()A-Za-z]{2,30})/);
console.log('\n正则猜到的课程/试卷名:', m ? m[1] : '(无)');
