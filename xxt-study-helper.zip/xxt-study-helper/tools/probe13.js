(function () {
  const out = [];
  const url = '/exam-ans/exam/test/reVersionPaperMarkContentNew?courseId=255245407&classId=128925575&p=1&id=169550368&ut=s&openc=807f581a17de304191ec9136c3fd1f64&times=1&newMooc=true';
  return new Promise(function (resolve) {
    const t = setTimeout(function () { out.push('TIMEOUT'); resolve(out.join('\n')); }, 20000);
    jQuery.ajax({
      type: 'get', url: url, dataType: 'html',
      success: function (data) {
        clearTimeout(t);
        const s = String(data);
        ['rightAnswerContent', 'qtAnalysis', 'stuAnswerContent', 'mark_answer', '正确答案', '解析'].forEach(function (k) {
          out.push(k + ' : ' + (s.split(k).length - 1));
        });
        out.push('---- CSS 里是否有这些类定义 ----');
        const css = [...document.querySelectorAll('link[rel=stylesheet]')].map(function (l) { return l.href; });
        out.push(css.join('\n'));
        out.push('---- 判断题(第16题)完整 HTML ----');
        const m = s.match(/<div class="marBom60 questionLi[^"]*"[^>]*data="885126169"[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/);
        if (m) out.push(m[0].slice(0, 2500)); else out.push('未匹配到');
        resolve(out.join('\n'));
      },
      error: function (xhr, st, e) { clearTimeout(t); out.push('ERR ' + st); resolve(out.join('\n')); }
    });
  });
})();
