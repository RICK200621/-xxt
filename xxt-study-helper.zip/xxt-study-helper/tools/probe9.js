function fmt(v) {
  try {
    if (typeof v === 'string') return v;
    return JSON.stringify(v, null, 1);
  } catch (e) {
    return String(v);
  }
}

(async function () {
  const out = [];
  const u = 'https://stat2-ans.chaoxing.com/study-knowledge/ans?courseid=255245407&cpi=415894527&clazzid=128925575&ut=s&relationId=7877691&type=4';
  try {
    const r = await fetch(u, { credentials: 'include' });
    const t = await r.text();
    out.push('status=' + r.status + ' len=' + t.length);
    out.push(t.slice(0, 2000));
  } catch (e) {
    out.push('ERR ' + e);
  }
  return out.join('\n');
})();
