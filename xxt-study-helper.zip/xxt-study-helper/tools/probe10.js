(function () {
  const out = [];
  const url = '/exam-ans/exam/test/answerlist?courseId=255245407&classId=128925575&cpi=415894527&id=169550368&ut=s&openc=807f581a17de304191ec9136c3fd1f64&newMooc=true';
  return new Promise(function (resolve) {
    const t = setTimeout(function () {
      out.push('TIMEOUT');
      resolve(out.join('\n'));
    }, 15000);
    jQuery.ajax({
      type: 'get',
      url: url,
      dataType: 'html',
      success: function (data) {
        clearTimeout(t);
        out.push('OK len=' + String(data).length);
        out.push(String(data).slice(0, 3000));
        resolve(out.join('\n'));
      },
      error: function (xhr, st, e) {
        clearTimeout(t);
        out.push('ERR ' + st + ' ' + e + ' status=' + (xhr && xhr.status));
        out.push(String((xhr && xhr.responseText) || '').slice(0, 1000));
        resolve(out.join('\n'));
      }
    });
  });
})();
