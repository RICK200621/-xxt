(function () {
  const out = [];
  out.push('URL: ' + location.href);
  out.push('title: ' + document.title);
  out.push('frames: ' + window.frames.length);
  out.push('body 文本长度: ' + (document.body ? document.body.innerText.length : -1));
  const t = document.body ? document.body.innerText : '';
  out.push('---- 关键词计数（body 文本） ----');
  ['正确答案', '参考答案', '解析', '我的答案', '你的答案', '查看答案', '错题解析'].forEach(function (k) {
    out.push('  ' + k + ' : ' + (t.split(k).length - 1));
  });
  out.push('---- body 前 2500 字 ----');
  out.push(t.slice(0, 2500));
  return out.join('\n');
})();
